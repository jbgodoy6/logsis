@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 exit /b 1
)
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --no-index --find-links=wheels --require-hashes -r requirements.txt
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" bancada.py %*
exit /b %errorlevel%
