"""Local, bounded receiver for OCPP 1.6 diagnostic uploads."""
import gzip
import io
import ipaddress
import re
import secrets
import threading
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import PurePosixPath
from urllib.parse import urlsplit

MAX_UPLOAD = 8 * 1024 * 1024
MAX_TEXT = 16 * 1024 * 1024
IDENTIFIER = re.compile(
    r'(?im)\b(evcc[ _-]*id|vin|vehicle[ _-]*id|ev[ _-]*mac(?:[ _-]*address)?|'
    r'battery(?:[ _-]*pack)?[ _-]*serial(?:[ _-]*number)?|bms[ _-]*serial(?:[ _-]*number)?)'
    r'["\x27]?\s*(?:[:=]|\s)\s*["\x27]?([A-Za-z0-9][A-Za-z0-9_.:-]{3,63})(?![A-Za-z0-9_.:-])'
)
VIN = re.compile(r'[A-HJ-NPR-Z0-9]{17}')


def candidates(payload):
    """Read bounded text in memory, without unpacking paths or logging contents."""
    stream = io.BytesIO(payload)
    try:
        if zipfile.is_zipfile(stream):
            with zipfile.ZipFile(stream) as archive:
                entries = [entry for entry in archive.infolist() if not entry.is_dir()]
                if len(entries) > 128 or sum(entry.file_size for entry in entries) > MAX_TEXT:
                    raise ValueError('ZIP fora dos limites de leitura')
                bodies = [
                    archive.read(entry) for entry in entries
                    if PurePosixPath(entry.filename).suffix.lower() in ('', '.txt', '.log', '.json', '.csv')
                ]
            format_name = 'ZIP'
        elif payload.startswith(b'\x1f\x8b'):
            with gzip.GzipFile(fileobj=stream) as archive:
                output = archive.read(MAX_TEXT + 1)
            if len(output) > MAX_TEXT:
                raise ValueError('GZIP fora dos limites de leitura')
            bodies, format_name = [output], 'GZIP'
        else:
            bodies, format_name = [payload], 'texto ou opaco'
    except (OSError, EOFError, RuntimeError, zipfile.BadZipFile, NotImplementedError) as exc:
        raise ValueError('Formato de diagnóstico não pôde ser lido') from exc

    found = set()
    for body in bodies:
        text = body.decode('utf-8', errors='replace')
        for match in IDENTIFIER.finditer(text):
            field, value = match.groups()
            kind = re.sub(r'[ _-]', '', field).lower()
            if kind == 'vin' and not VIN.fullmatch(value.upper()):
                continue
            found.add((kind, value))
            if len(found) >= 64:
                break
        if len(found) >= 64:
            break
    return format_name, sorted(found)


class Receiver:
    def __init__(self, host, port, notify, progress=lambda stage: None):
        address = ipaddress.IPv4Address(host)
        if address.is_loopback or address.is_unspecified or address.is_multicast or not address.is_private:
            raise ValueError('Use o IPv4 da Ethernet do PC ligada ao carregador')
        self.host = str(address)
        self.ticket = None
        self.lock = threading.Lock()
        receiver = self

        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                self.request.settimeout(5)
                super().setup()
                with receiver.lock:
                    ticket = receiver.ticket
                if ticket and self.client_address[0] == ticket[0]:
                    progress('conexão TCP aceita')

            def log_message(self, *_):
                pass

            def do_PUT(self):
                path = urlsplit(self.path).path
                with receiver.lock:
                    ticket = receiver.ticket
                    if (ticket is None or self.client_address[0] != ticket[0]
                            or not (path == ticket[1] or path.startswith(ticket[1] + '/'))):
                        if ticket and self.client_address[0] == ticket[0]:
                            progress('endereço de upload não corresponde ao pedido')
                        self.send_error(403)
                        return
                progress(f'pedido {self.command} recebido')
                lengths = self.headers.get_all('Content-Length', [])
                if (len(lengths) != 1 or not re.fullmatch(r'[0-9]{1,9}', lengths[0])
                        or self.headers.get('Transfer-Encoding')):
                    progress('envio sem Content-Length válido ou com codificação não suportada')
                    self.send_error(411)
                    return
                length = int(lengths[0])
                if not 0 < length <= MAX_UPLOAD:
                    progress('tamanho fora do limite')
                    self.send_error(413)
                    return
                try:
                    payload = self.rfile.read(length)
                except (TimeoutError, OSError):
                    return
                if len(payload) != length:
                    self.send_error(400)
                    return
                with receiver.lock:
                    if receiver.ticket != ticket:
                        self.send_error(409)
                        return
                    receiver.ticket = None
                self.send_response(200)
                self.send_header('Content-Length', '0')
                self.end_headers()
                try:
                    form, matched = candidates(payload)
                except ValueError:
                    notify(len(payload), 'ilegível', [])
                else:
                    notify(len(payload), form, matched)

            do_POST = do_PUT

            def do_GET(self):
                self.send_error(405)

        self.server = ThreadingHTTPServer((self.host, port), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def issue(self, peer):
        path = '/diagnostico/' + secrets.token_urlsafe(24)
        with self.lock:
            self.ticket = (peer, path)
        return f'http://{self.host}:{self.server.server_port}{path}'

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
