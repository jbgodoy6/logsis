"""Bancada supervisionada OCPP 1.6 JSON."""
import argparse
import asyncio
import csv
import hmac
import json
import math
import re
import secrets
import sys
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

CONNECTOR = 1
PROFILE_ID = 200002
COMPARE_PROFILES = {
    "igual": (PROFILE_ID, 1, "Absolute"),
    "novo": (PROFILE_ID + 1, 1, "Absolute"),
    "prioridade": (PROFILE_ID + 1, 2, "Absolute"),
    "relativo": (PROFILE_ID, 1, "Relative"),
}
ID_TAG = "BANCADA-DMAX"
LEASE = 90
TIMEOUT = 45
START_TIMEOUT = 60
FRESH = 15
SETTLE = 2
SPAN = 5
VEHICLE_FIELDS = {
    "evccid": "EVCCID", "evccidentifier": "EVCCID",
    "vin": "VIN", "vehiclevin": "VIN", "vehicleidentificationnumber": "VIN",
    "vehicleid": "Vehicle ID", "vehicleidentifier": "Vehicle ID", "evid": "Vehicle ID",
    "evmac": "MAC candidato", "evmacaddress": "MAC candidato",
    "vehiclemac": "MAC candidato", "vehiclemacaddress": "MAC candidato",
    "macaddress": "MAC candidato", "autochargeid": "Autocharge",
    "emaid": "eMAID", "contractid": "Contrato candidato",
    "contractcertificateid": "Certificado candidato",
    "contractcertificateserialnumber": "Certificado candidato",
    "batteryid": "Bateria", "batterypackid": "Bateria",
    "batteryserial": "Bateria", "batteryserialnumber": "Bateria",
    "batterypackserial": "Bateria", "batterypackserialnumber": "Bateria",
    "bmsid": "BMS", "bmsserial": "BMS", "bmsserialnumber": "BMS",
    "idtag": "Credencial candidata",
}
TEXT_FIELD = re.compile(r"([A-Za-z][A-Za-z0-9_. -]{0,63})\s*[:=]\s*([^\r\n;,|]{1,128})")


def vehicle_kind(field):
    if isinstance(field, str):
        return VEHICLE_FIELDS.get(re.sub(r"[^a-z0-9]", "", field.lower()))
    return None
STATUS = {
    "Available", "Preparing", "Charging", "SuspendedEV", "SuspendedEVSE",
    "Finishing", "Reserved", "Unavailable", "Faulted",
}


def utc():
    return datetime.now(timezone.utc)


def iso():
    return utc().isoformat(timespec="seconds").replace("+00:00", "Z")


def watts(value):
    result = Decimal(value.replace(",", ".")) * 1000
    if not result.is_finite() or not 0 < result <= 60000 or result != result.to_integral_value():
        raise ValueError("Use potência positiva de até 60 kW, em watts inteiros.")
    return int(result)


def profile(target, tx=None, *, profile_id=PROFILE_ID, stack=1, kind="Absolute"):
    data = dict(chargingProfileId=profile_id, stackLevel=stack, chargingProfileKind=kind,
                chargingProfilePurpose="TxProfile",
                chargingSchedule=dict(chargingRateUnit="W",
                                      chargingSchedulePeriod=[
                                          dict(startPeriod=0, limit=target),
                                          dict(startPeriod=LEASE, limit=0),
                                      ]))
    if kind == "Absolute":
        data["chargingSchedule"]["startSchedule"] = iso()
    if tx is not None:
        data["transactionId"] = tx
    return data


class Log:
    def __init__(self, directory):
        directory.mkdir(parents=True, exist_ok=True)
        stem = directory / (utc().strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8])
        self.json = stem.with_suffix(".jsonl").open("x", encoding="utf-8")
        self.csv = stem.with_suffix(".csv").open("x", encoding="utf-8-sig", newline="")
        self.writer = csv.writer(self.csv)
        self.writer.writerow(("utc", "evento", "potencia_w", "intervalo_s", "dados"))
        self.csv.flush()

    def __call__(self, event, **data):
        stamp = iso()
        print(stamp, event, json.dumps(data, ensure_ascii=False), flush=True)
        self.json.write(json.dumps(dict(utc=stamp, evento=event, **data), ensure_ascii=False) + "\n")
        self.writer.writerow((stamp, event, data.get("potencia_w"), data.get("intervalo_s"),
                              json.dumps(data, ensure_ascii=False)))
        self.json.flush()
        self.csv.flush()


class Bench:
    def __init__(self, log):
        self.log = log
        self.ws = None
        self.active_profile = COMPARE_PROFILES["igual"]
        self.vehicle_key = secrets.token_bytes(32)
        self.vehicle_seen = set()
        self.pending = {}
        self.tx = None
        self.next_tx = int(time.time())
        self.ended_tx = None
        self.ceiling = 0
        self.status = None
        self.last_stamp = None
        self.sample = None
        self.samples = deque(maxlen=256)
        self.updated = asyncio.Event()
        self.job = None
        self.manual = False
        self.next_command = None
        self.stopping = False
        self.failed = False
        self.start_requested = False
        self.stop_pending = False

    async def call(self, action, **payload):
        ws = self.ws
        if ws is None:
            raise RuntimeError("Carregador desconectado")
        key = uuid.uuid4().hex
        future = asyncio.get_running_loop().create_future()
        self.pending[key] = future
        public = {k: v for k, v in payload.items() if k != "idTag"}
        self.log("pedido", acao=action, **public)
        try:
            await ws.send(json.dumps([2, key, action, payload]))
            reply = await asyncio.wait_for(future, 5)
        except (TimeoutError, ConnectionClosed, RuntimeError):
            self.log("erro de comando", acao=action)
            raise
        finally:
            self.pending.pop(key, None)
        response = {}
        if reply is None:
            self.log("erro OCPP", acao=action)
        if isinstance(reply, dict):
            if reply.get("status") in {"Accepted", "Rejected", "NotSupported", "RebootRequired", "NotImplemented"}:
                response["status"] = reply["status"]
            if action == "GetConfiguration":
                response["intervalo_configurado"] = next((
                    int(row["value"]) for row in reply.get("configurationKey", [])
                    if row.get("key") == "MeterValueSampleInterval"
                    and str(row.get("value", "")).isascii()
                    and str(row.get("value", "")).isdigit()
                    and len(str(row["value"])) <= 9
                ), None)
            if action == "GetCompositeSchedule" and response.get("status") == "Accepted":
                schedule = reply.get("chargingSchedule", {})
                if isinstance(schedule, dict):
                    unit = schedule.get("chargingRateUnit")
                    response["unidade"] = unit if unit in ("W", "A") else None
                    response["periodos"] = [
                        {k: row[k] for k in ("startPeriod", "limit") if type(row.get(k)) in (float, int)}
                        for row in schedule.get("chargingSchedulePeriod", []) if isinstance(row, dict)
                    ]
        self.log("resposta", acao=action, **response)
        return response

    async def handler(self, ws):
        if (ws.request.path != "/ocpp/car002" or ws.subprotocol != "ocpp1.6"
                or self.ws is not None or self.stopping or (self.job and not self.job.done())):
            await ws.close(1008)
            return
        self.ws = ws
        self.vehicle_seen.clear()
        self.failed = False
        self.log("conectado", ip=ws.remote_address[0])
        try:
            async for raw in ws:
                try:
                    await self.receive(ws, json.loads(raw))
                except (ValueError, TypeError, KeyError, AttributeError, OverflowError):
                    self.log("mensagem inválida")
        except ConnectionClosed:
            pass
        finally:
            self.ws = None
            self.tx = None
            self.ceiling = 0
            self.status = None
            self.sample = None
            self.last_stamp = None
            self.start_requested = False
            for future in self.pending.values():
                if not future.done():
                    future.set_exception(RuntimeError("Conexão encerrada"))
            self.updated.set()
            self.log("desconectado")

    def record_vehicle(self, action, kind, value, tx):
        if type(value) not in (str, int):
            return
        identifier = str(value).strip()
        if not 1 <= len(identifier) <= 128 or identifier.upper() == ID_TAG:
            return
        if kind in ("VIN", "EVCCID", "MAC candidato"):
            identifier = identifier.upper()
        fingerprint = hmac.digest(self.vehicle_key, (kind + ":" + identifier).encode(), "sha256").hex()[:24]
        marker = (tx, kind, fingerprint)
        if marker not in self.vehicle_seen and len(self.vehicle_seen) < 128:
            self.vehicle_seen.add(marker)
            self.log("identificador de veículo observado", tipo=kind, impressao=fingerprint,
                     origem=action, transacao=tx)

    def observe_vehicle(self, action, data, tx=None):
        fields = [(data, 0)]
        while fields:
            item, depth = fields.pop()
            if depth > 6:
                continue
            if isinstance(item, list):
                fields.extend((child, depth + 1) for child in item)
                continue
            if not isinstance(item, dict):
                continue
            for label in ("measurand", "name", "key", "type"):
                kind = vehicle_kind(item.get(label))
                if kind:
                    self.record_vehicle(action, kind, item.get("value", item.get("idToken")), tx)
                    break
            for key, value in item.items():
                kind = vehicle_kind(key)
                if isinstance(value, (dict, list)):
                    fields.append((value, depth + 1))
                elif kind:
                    self.record_vehicle(action, kind, value, tx)

    def observe_transfer(self, payload):
        if isinstance(payload, str) and len(payload) <= 16384:
            try:
                payload = json.loads(payload)
            except (ValueError, RecursionError):
                fields = [TEXT_FIELD.fullmatch(part.strip()) for part in re.split(r"[;|,\r\n]", payload)]
                payload = {match[1].strip(): match[2].strip() for match in fields if match}
        if not isinstance(payload, (dict, list)):
            return
        connector = payload.get("connectorId") if isinstance(payload, dict) else None
        transaction = payload.get("transactionId") if isinstance(payload, dict) else None
        if connector not in (None, CONNECTOR, str(CONNECTOR)):
            return
        if transaction is not None and (self.tx is None or str(transaction) != str(self.tx)):
            return
        self.observe_vehicle("DataTransfer", payload, self.tx if transaction is not None else None)

    async def receive(self, ws, frame):
        if not isinstance(frame, list) or not frame:
            raise ValueError()
        if len(frame) >= 3 and frame[0] in (3, 4) and isinstance(frame[1], str):
            future = self.pending.get(frame[1])
            if future and not future.done():
                future.set_result(frame[2] if frame[0] == 3 else None)
            return
        if len(frame) != 4 or frame[0] != 2 or not isinstance(frame[3], dict):
            raise ValueError()
        _, key, action, data = frame
        result = {}
        if action == "BootNotification":
            result = dict(status="Accepted", currentTime=iso(), interval=30)
        elif action == "Heartbeat":
            result = dict(currentTime=iso())
        elif action == "Authorize":
            self.observe_vehicle(action, data)
            result = dict(idTagInfo=dict(status="Accepted" if data.get("idTag") == ID_TAG
                                         and self.start_requested else "Invalid"))
        elif action == "StatusNotification":
            if data.get("connectorId") == CONNECTOR:
                self.observe_vehicle(action, data)
            status = data.get("status")
            if data.get("connectorId") in (0, CONNECTOR) and status in STATUS:
                self.log("status", conector=data["connectorId"], estado=status)
                if data["connectorId"] == CONNECTOR or status in ("Faulted", "Unavailable"):
                    self.status = status
                    if status in ("Faulted", "Unavailable", "Finishing") and self.job and not self.job.done():
                        self.failed = True
                    self.updated.set()
        elif action == "StartTransaction":
            allowed = (data.get("connectorId") == CONNECTOR and self.tx is None
                       and data.get("idTag") == ID_TAG and (self.start_requested or self.stop_pending))
            self.next_tx += int(allowed)
            result = dict(transactionId=self.next_tx if allowed else 0,
                          idTagInfo=dict(status="Accepted" if allowed else "Invalid"))
            if allowed:
                self.tx = self.next_tx
                self.sample = self.last_stamp = None
                self.samples.clear()
                self.log("transação iniciada", transacao=self.tx)
                self.observe_vehicle(action, data, self.tx)
                self.updated.set()
            elif data.get("connectorId") == CONNECTOR:
                self.observe_vehicle(action, data)
        elif action == "StopTransaction":
            if self.tx is not None and data.get("transactionId") == self.tx:
                self.observe_vehicle(action, data, self.tx)
                if not any(tx == self.tx and kind != "Credencial candidata" for tx, kind, _ in self.vehicle_seen):
                    self.log("identificador de veículo não observado", transacao=self.tx)
                self.vehicle_seen = {entry for entry in self.vehicle_seen if entry[0] != self.tx}
                self.log("transação encerrada", transacao=self.tx)
                self.ended_tx = self.tx
                self.tx = None
                self.updated.set()
        elif action == "MeterValues":
            if self.tx is not None and data.get("connectorId") == CONNECTOR and data.get("transactionId") == self.tx:
                self.observe_vehicle(action, data, self.tx)
                for meter in data.get("meterValue", []):
                    self.meter(meter)
            else:
                if data.get("connectorId") == CONNECTOR and data.get("transactionId") is None:
                    self.observe_vehicle(action, data)
                self.log("medição ignorada", motivo="conector ou transação fora do ensaio")
        elif action == "DataTransfer":
            self.observe_transfer(data.get("data"))
            result = dict(status="UnknownMessageId")
        else:
            await ws.send(json.dumps([4, key, "NotImplemented", "", {}]))
            return
        await ws.send(json.dumps([3, key, result]))
        if action == "StartTransaction" and self.tx is not None and self.stop_pending and not self.stopping:
            asyncio.create_task(self.shutdown())

    def meter(self, meter):
        try:
            stamp = datetime.fromisoformat(meter["timestamp"].replace("Z", "+00:00"))
            if stamp.tzinfo is None:
                raise ValueError()
            age = (utc() - stamp).total_seconds()
        except (ValueError, TypeError, KeyError, AttributeError):
            self.log("medição ignorada", motivo="timestamp inválido")
            return
        if not -5 <= age <= FRESH:
            self.log("medição ignorada", motivo="timestamp antigo ou futuro", idade_s=age)
            return
        if self.last_stamp is not None and stamp <= self.last_stamp:
            self.log("medição ignorada", motivo="timestamp repetido ou fora de ordem")
            return
        self.last_stamp = stamp
        power, soc = [], None
        for entry in meter.get("sampledValue", []):
            if entry.get("format", "Raw") != "Raw":
                continue
            try:
                value = float(entry.get("value"))
            except (TypeError, ValueError):
                continue
            if not math.isfinite(value):
                continue
            if entry.get("measurand") == "SoC" and entry.get("unit", "Percent") == "Percent" and 0 <= value <= 100:
                soc = value
            if entry.get("measurand") == "Power.Active.Import" and not entry.get("phase"):
                unit = entry.get("unit", "W")
                if unit in ("W", "kW") and value >= 0:
                    power.append(value * (1000 if unit == "kW" else 1))
        if len(power) != 1 or not math.isfinite(power[0]):
            self.log("sem potência válida", soc=soc, motivo="Power.Active.Import total ausente ou ambíguo")
            return
        interval = (stamp - self.sample[0]).total_seconds() if self.sample else None
        self.sample = (stamp, time.monotonic(), power[0])
        self.samples.append(self.sample)
        self.log("medição", potencia_w=power[0], intervalo_s=interval, soc=soc, transacao=self.tx)
        self.updated.set()

    async def wait_update(self, seconds):
        self.updated.clear()
        try:
            await asyncio.wait_for(self.updated.wait(), max(0, seconds))
        except TimeoutError:
            pass

    async def observe(self, target, since, tx, hold=0):
        tolerance = target * .15
        deadline = since[1] + TIMEOUT
        hold_deadline = None
        first = last = confirmed = None
        count = 0
        while True:
            now = time.monotonic()
            if self.ws is None or self.tx != tx:
                raise RuntimeError("Conexão ou transação perdida")
            if self.failed:
                raise RuntimeError("Estado do conector interrompeu o ensaio")
            sample = self.sample
            if now - max(since[1], sample[1] if sample else 0) >= FRESH:
                raise RuntimeError("Sem telemetria recente")
            if now >= (hold_deadline if confirmed is not None else deadline):
                raise RuntimeError("Prazo de confirmação ou permanência excedido")
            for candidate in self.samples:
                stamp, received, power = candidate
                if last is not None and stamp <= last:
                    continue
                last = stamp
                if stamp > since[0] and received >= since[1] + SETTLE and stamp.timestamp() >= since[0].timestamp() + SETTLE:
                    if abs(power - target) <= tolerance:
                        if first is None:
                            first = stamp
                            first_received = received
                        count += 1
                        if count >= 3 and (stamp - first).total_seconds() >= SPAN and received - first_received >= SPAN:
                            if confirmed is None:
                                self.log("potência confirmada", alvo_w=target, potencia_w=power, transacao=tx)
                                confirmed = received
                                hold_deadline = min(received + hold + FRESH, since[1] + LEASE - 12)
                            if received - confirmed >= hold:
                                return
                    else:
                        if confirmed is not None:
                            raise RuntimeError("Potência saiu da faixa durante a permanência")
                        first = None
                        count = 0
            await self.wait_update(.25)

    async def apply(self, target, tx):
        if self.tx != tx or self.ws is None:
            raise RuntimeError("Transação mudou")
        if target and (target > self.ceiling or self.failed or self.status in ("Faulted", "Unavailable", "Finishing")):
            raise RuntimeError("Potência ou estado fora da autorização")
        profile_id, stack, kind = self.active_profile
        response = await self.call("SetChargingProfile", connectorId=CONNECTOR,
                                   csChargingProfiles=profile(target, tx, profile_id=profile_id, stack=stack, kind=kind))
        if response.get("status") != "Accepted":
            raise RuntimeError("Perfil recusado ou resposta inválida")

    async def schedule_snapshot(self, stage, tx):
        try:
            response = await self.call("GetCompositeSchedule", connectorId=CONNECTOR, duration=60, chargingRateUnit="W")
        except (RuntimeError, TimeoutError, ConnectionClosed, TypeError, ValueError):
            response = {}
        self.log("plano comparativo", etapa=stage, transacao=tx, **response)

    async def run(self, targets, *, start=False, hold=0, manual=False, comparison=None):
        self.active_profile = COMPARE_PROFILES["igual"]
        try:
            if start:
                self.start_requested = True
                reply = await self.call("RemoteStartTransaction", connectorId=CONNECTOR,
                                        idTag=ID_TAG, chargingProfile=profile(targets[0]))
                if reply.get("status") != "Accepted":
                    raise RuntimeError("Partida recusada")
                deadline = time.monotonic() + START_TIMEOUT
                while self.tx is None:
                    if self.ws is None or time.monotonic() >= deadline or self.failed:
                        raise RuntimeError("Transação não iniciou")
                    await self.wait_update(.25)
                self.start_requested = False
            tx = self.tx
            while True:
                for index, target in enumerate(targets):
                    if comparison and index == 1:
                        await self.schedule_snapshot("antes da troca", tx)
                        self.active_profile = COMPARE_PROFILES[comparison]
                    if self.sample is not None and time.monotonic() - self.sample[1] >= FRESH:
                        raise RuntimeError("Sem telemetria recente antes do próximo comando")
                    sent = time.monotonic()
                    await self.apply(target, tx)
                    since = (utc(), time.monotonic())
                    if comparison and index == 1:
                        await self.schedule_snapshot("depois da troca", tx)
                    await self.observe(target, since, tx, hold)
                if not manual:
                    break
                self.manual = True
                self.log("aguardando próximo comando", limite_s=30)
                deadline = min(time.monotonic() + 30, sent + LEASE - 10)
                while self.next_command is None:
                    if (time.monotonic() >= deadline or self.tx != tx or self.ws is None
                            or self.failed or time.monotonic() - self.sample[1] >= FRESH):
                        raise RuntimeError("Fim da janela manual ou perda de estado/telemetria")
                    await self.wait_update(.25)
                targets, hold, manual = self.next_command
                self.next_command = None
                self.manual = False
        except asyncio.CancelledError:
            self.log("ensaio cancelado")
        except (RuntimeError, TimeoutError, ConnectionClosed) as exc:
            self.log("ensaio abortado", motivo=str(exc) if isinstance(exc, RuntimeError) else type(exc).__name__)
        finally:
            self.manual = False
            self.next_command = None
            await self.shutdown()

    async def shutdown(self):
        if self.stopping:
            return
        self.stopping = True
        self.ceiling = 0
        if self.start_requested:
            self.stop_pending = True
        self.start_requested = False
        tx = self.tx
        try:
            if tx is None or self.ws is None:
                self.log("zero e parada não confirmados", motivo="sem transação conectada; verifique no painel")
                return
            since = (utc(), time.monotonic())
            for action in ("SetChargingProfile", "RemoteStopTransaction"):
                try:
                    if action == "SetChargingProfile":
                        await self.apply(0, tx)
                    elif self.tx == tx:
                        reply = await self.call(action, transactionId=tx)
                        if reply.get("status") != "Accepted":
                            self.log("pedido sem aceite confirmado", acao=action)
                except (RuntimeError, TimeoutError, ConnectionClosed):
                    self.log("pedido sem aceite confirmado", acao=action)
            deadline = time.monotonic() + FRESH
            zero = False
            while True:
                sample = self.sample
                if sample and sample[0] > since[0] and sample[1] > since[1] and sample[2] <= 200:
                    self.log("zero medido", potencia_w=sample[2], transacao=tx)
                    zero = True
                    break
                if self.ws is None or self.tx != tx or time.monotonic() >= deadline:
                    break
                await self.wait_update(.25)
            if not zero:
                self.log("zero físico não confirmado", transacao=tx)
            while self.ws is not None and self.tx == tx and time.monotonic() < deadline:
                await self.wait_update(.25)
            self.log("verificação de parada", encerrada=self.ended_tx == tx)
            if self.tx is not None or self.ws is None:
                self.log("verifique a parada no painel")
            else:
                self.stop_pending = False
        finally:
            if self.ended_tx == tx and self.status not in ("Faulted", "Unavailable"):
                self.failed = False
            self.stopping = False

    async def stop(self):
        if self.job and not self.job.done():
            if not self.stopping:
                self.job.cancel()
            try:
                await self.job
            except asyncio.CancelledError:
                await self.shutdown()
        else:
            await self.shutdown()

    def launch(self, targets, start=False, hold=0, manual=False, comparison=None):
        if self.stopping:
            raise ValueError("Parada em andamento")
        if (not self.ws or not self.ceiling or max(targets) > self.ceiling
                or self.status in ("Faulted", "Unavailable", "Finishing")):
            raise ValueError("Confira conexão, estado e teto habilitado")
        if start == (self.tx is not None) or self.stop_pending or self.failed:
            raise ValueError("Confira o estado da transação e da parada")
        if self.job and not self.job.done():
            if start or not self.manual or self.next_command is not None:
                raise ValueError("Aguarde a confirmação física do alvo atual")
            self.next_command = (targets, hold, manual)
            self.updated.set()
            return
        self.job = asyncio.create_task(self.run(targets, start=start, hold=hold, manual=manual, comparison=comparison))

    async def command(self, line):
        cmd, *args = line.lower().split()
        if cmd == "status" and not args:
            self.log("estado", conectado=self.ws is not None, estado=self.status, transacao=self.tx,
                     teto_w=self.ceiling, potencia_w=self.sample[2] if self.sample else None,
                     idade_s=time.monotonic() - self.sample[1] if self.sample else None)
        elif cmd == "arm" and len(args) == 1:
            if not self.ws or self.stopping or (self.job and not self.job.done()):
                raise ValueError("Conecte o carregador e aguarde o fim do ensaio")
            self.ceiling = watts(args[0])
            self.log("teto habilitado", teto_w=self.ceiling)
        elif cmd in ("start", "set") and len(args) == 1:
            self.launch([watts(args[0])], start=cmd == "start", manual=True)
        elif cmd == "compare" and len(args) == 3:
            mode, initial, final = args
            low, high = watts(initial), watts(final)
            if mode not in COMPARE_PROFILES or low >= high or high > 10000:
                raise ValueError("Use compare igual|novo|prioridade|relativo INICIAL FINAL, com aumento até 10 kW")
            self.launch([low, high], start=True, comparison=mode)
            self.log("comparação iniciada", modo=mode, inicial_w=low, final_w=high)
        elif cmd == "ramp" and len(args) == 3:
            first, step, end = map(watts, args)
            if first > end or (end - first) // step >= 60:
                raise ValueError("Rampa inválida ou com mais de 60 degraus")
            targets = list(range(first, end + 1, step))
            if targets[-1] != end:
                targets.append(end)
            self.launch(targets)
        elif cmd == "cycle" and len(args) == 4:
            low, high = map(watts, args[:2])
            hold, count = map(int, args[2:])
            if not (low < high and 1 <= hold <= 30 and 1 <= count <= 30):
                raise ValueError("Use valores crescentes, permanência de 1 a 30 s e 1 a 30 ciclos")
            self.launch([low, high] * count, hold=hold)
        elif cmd == "stop" and not args:
            await self.stop()
        elif cmd in ("cfg", "schedule", "sample"):
            if cmd == "schedule" and not args:
                await self.call("GetCompositeSchedule", connectorId=CONNECTOR, duration=60, chargingRateUnit="W")
            elif cmd == "cfg" and not args:
                await self.call("GetConfiguration", key=["MeterValueSampleInterval"])
            elif cmd == "sample" and len(args) == 1 and 1 <= int(args[0]) <= 60:
                if self.job and not self.job.done():
                    raise ValueError("Altere a amostragem fora do ensaio")
                await self.call("ChangeConfiguration", key="MeterValueSampleInterval", value=str(int(args[0])))
                config = await self.call("GetConfiguration", key=["MeterValueSampleInterval"])
                self.log("verificação da amostragem", solicitado_s=int(args[0]),
                         confirmado=config.get("intervalo_configurado") == int(args[0]))
            else:
                raise ValueError("Use cfg, schedule ou sample 1..60")
        else:
            raise ValueError("Comando inválido")


async def main(args):
    bench = Bench(Log(args.logs))
    loop = asyncio.get_running_loop()
    queue = asyncio.Queue()

    def read():
        for line in sys.stdin:
            loop.call_soon_threadsafe(queue.put_nowait, line.strip())
        loop.call_soon_threadsafe(queue.put_nowait, "quit")

    async with serve(bench.handler, args.host, args.port, subprotocols=["ocpp1.6"],
                     max_size=262144, ping_interval=5, ping_timeout=5):
        print("status | cfg | schedule | sample 5 | arm 10 | start 5 | set 7.5 | compare relativo 5 10 | ramp 5 5 10 | cycle 5 10 30 3 | stop | quit")
        threading.Thread(target=read, daemon=True).start()
        try:
            while (line := await queue.get()) != "quit":
                if line:
                    try:
                        await bench.command(line)
                    except (ArithmeticError, ValueError, RuntimeError, TimeoutError, ConnectionClosed) as exc:
                        bench.log("erro", motivo=str(exc) if isinstance(exc, (ValueError, RuntimeError)) else type(exc).__name__)
        finally:
            if bench.tx is not None or bench.start_requested or (bench.job and not bench.job.done()):
                await bench.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--logs", type=Path, default=Path("logs"))
    try:
        asyncio.run(main(parser.parse_args()))
    except KeyboardInterrupt:
        pass
