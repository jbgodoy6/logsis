"""One-use FTP diagnostic receiver with bounded in-memory staging."""
import errno
import io
import tempfile
import threading
import time
import warnings
from pathlib import Path

from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.filesystems import AbstractedFS
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

from diag_upload import MAX_UPLOAD, candidates


class FTPReceiver:
    def __init__(self, host, port, data_port, notify, progress=lambda stage: None):
        self.host = host
        self.peer = self.user = None
        self.expires = 0.0
        self.files = {}
        self.guard = threading.Lock()
        self.directory = tempfile.TemporaryDirectory(prefix='dmax-diag-ftp-')
        self.auth = DummyAuthorizer()
        receiver = self

        class MemoryFile(io.BytesIO):
            def __init__(self, name):
                super().__init__()
                self.name = name

            def write(self, data):
                if self.tell() + len(data) > MAX_UPLOAD:
                    raise OSError(errno.ENOSPC, 'Diagnóstico excede o limite')
                return super().write(data)

            def close(self):
                if not self.closed:
                    with receiver.guard:
                        if self.name in receiver.files:
                            receiver.files[self.name] = self.getvalue()
                super().close()

        class UploadFS(AbstractedFS):
            def open(self, filename, mode):
                with receiver.guard:
                    if (mode != 'wb' or receiver.user is None or receiver.files
                            or self.cmd_channel.username != receiver.user or time.monotonic() >= receiver.expires):
                        raise OSError(errno.EACCES, 'Envio indisponível')
                    receiver.files[filename] = None
                progress('comando STOR recebido')
                return MemoryFile(filename)

        class Handler(FTPHandler):
            abstracted_fs = UploadFS
            authorizer = receiver.auth
            passive_ports = [data_port]
            timeout = 25

            def on_connect(self):
                if (self.remote_ip != receiver.peer or receiver.user is None
                        or time.monotonic() >= receiver.expires):
                    self.close()
                else:
                    progress('conexão TCP aceita')

            def on_login(self, username):
                progress('login aceito')

            def on_login_failed(self, username, password):
                category = 'anônimo' if username.lower() == 'anonymous' else 'outro usuário'
                progress(f'login recusado ({category})')

            def log(self, *_args, **_kwargs):
                pass

            logline = log
            log_transfer = log

            def on_incomplete_file_received(self, filename):
                with receiver.guard:
                    receiver.files.pop(filename, None)
                progress('transferência interrompida')

            def on_file_received(self, filename):
                with receiver.guard:
                    payload = receiver.files.pop(filename, None)
                    valid = bool(payload) and receiver.user == self.username and time.monotonic() < receiver.expires
                    if valid:
                        receiver.auth.remove_user(receiver.user)
                        receiver.user = None
                if valid:
                    try:
                        form, matched = candidates(payload)
                    except ValueError:
                        notify(len(payload), 'ilegível', [])
                    else:
                        notify(len(payload), form, matched)

        try:
            self.server = FTPServer((host, port), Handler)
        except BaseException:
            self.directory.cleanup()
            raise
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'timeout': .1, 'handle_exit': False}, daemon=True)
        self.thread.start()

    def issue(self, peer):
        with self.guard:
            if self.user is not None:
                self.auth.remove_user(self.user)
            self.files.clear()
            # The stock authorizer warns about write access for anonymous FTP.
            # Source, expiry, one-file limit and in-memory storage are enforced above.
            with warnings.catch_warnings():
                warnings.filterwarnings('ignore', message='write permissions assigned to anonymous user.')
                self.auth.add_anonymous(str(Path(self.directory.name)), perm='ew')
            self.peer, self.user = peer, 'anonymous'
            self.expires = time.monotonic() + 45
        port = self.server.socket.getsockname()[1]
        authority = self.host if port == 21 else f'{self.host}:{port}'
        return f'ftp://{authority}/'

    def close(self):
        self.server.close_all()
        self.thread.join(timeout=3)
        self.directory.cleanup()
