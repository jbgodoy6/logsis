# Bancada OCPP do D-Max

Bancada independente para o Riseon S202, ID `car002`, conector 1 e OCPP 1.6 JSON. Use com o carregador e o veículo supervisionados e com acesso ao painel local.

## Iniciar no CMD

1. Encerre a recarga antes de trocar o servidor. Confirme o IP atual do carregador no painel ou na tabela DHCP. O último observado foi `192.168.100.141`. Confirme com `ipconfig` o IPv4 da interface do **Windows** na mesma rede. O Raspberry usava `192.168.100.183`.
2. Instale Python 3.10 ou mais recente, com o launcher `py` disponível no CMD. Extraia o ZIP e rode `iniciar.bat`. A primeira execução instala a dependência incluída no ZIP em `.venv`, sem acesso à internet. Mantenha a pasta `wheels` junto de `iniciar.bat`.
3. Configure no carregador `ws://IP_DO_WINDOWS:8080/ocpp/car002` e o subprotocolo `ocpp1.6`. A bancada valida caminho e subprotocolo sem Basic Authentication. Use só em rede privada isolada, sem redirecionar a porta para a internet. Se o firewall exigir uma regra, libere apenas TCP 8080 no perfil Privado com endereço remoto restrito ao IP confirmado do carregador.
4. Confira `status`, `cfg` e, se necessário, `sample 5`. A bancada lê o intervalo de volta e registra se corresponde ao pedido. `schedule` consulta o plano composto em W. Rejeições dessas consultas aparecem associadas à ação correspondente. A bancada não emite Reset nem limpa perfis.

## Ensaiar

- `arm 10` habilita até 10 kW nesta conexão. Defina o teto pela potência autorizada para a instalação durante o ensaio.
- `start 5` solicita partida com perfil inicial de 5 kW e aplica o perfil à transação recebida. O limite é enviado em W, com horário UTC terminado em `Z`. Use um conector por vez. A bancada aguarda até 60 segundos pela abertura da transação após o aceite.
- Aguarde **potência confirmada**. Na sessão manual iniciada por `start`, digite `7.5` ou `set 7.5` para mudar a potência na mesma transação, assim que houver uma leitura recente. Se o pedido anterior ainda estiver sendo medido, o novo valor substitui o alvo anterior. `ramp 5 5 10` testa 5 e 10 kW. `cycle 5 10 30 3` alterna 5 e 10 kW três vezes, sustentando cada alvo por pelo menos 30 segundos após confirmação.
- Cada degrau requer três amostras válidas, distintas e posteriores ao aceite, após 2 segundos de acomodação. As leituras devem cobrir pelo menos 5 segundos no relógio do carregador e na recepção, com tolerância de ±15% do alvo de potência (por exemplo, 8,5 a 11,5 kW para 10 kW). O primeiro prazo de confirmação é de 45 segundos. A bancada aborta após 15 segundos sem potência recente, perda da transação ou conexão, falha ou saída da faixa durante a permanência de um ciclo.
- `stop` cancela o ensaio e solicita zero e encerramento. A bancada também faz isso ao terminar rampa ou ciclo, ao abortar por falha ou perda de telemetria. `quit` encerra o programa e solicita parada se houver ensaio ou transação. Confira no painel quando a parada ou o zero físico ficarem sem confirmação, especialmente se o WebSocket cair. O perfil da bancada prevê zero a partir de 90 segundos, condicionado à aplicação pelo firmware.
- Consulte o CSV e o JSONL em `logs`. Pedidos, respostas, potência medida e encerramento da transação aparecem como eventos separados. Os logs omitem idTags e mensagens OCPP brutas. O intervalo exibido usa os timestamps das leituras válidas de potência.

O carregador simulado cobre a lógica OCPP. Confira se o Riseon aplica os perfis, fornece `Power.Active.Import` total em W ou kW e honra a parada antes de usar degraus maiores.

## Testes

Na pasta da bancada com a dependência instalada, rode `python -m unittest -v`. Os testes sobem um carregador simulado via WebSocket em loopback, sem Raspberry, planilha ou equipamento físico.

## Diagnóstico de identificação do carro

A bancada procura EVCCID, VIN, Vehicle ID, MAC candidato, Autocharge, eMAID, identificadores de contrato ou certificado e IDs ou números de série de bateria e BMS. Analisa mensagens de autorização, conector e transação, além de DataTransfer em JSON ou texto com pares chave-valor. Mensagens sem vínculo explícito com a transação aparecem com transação vazia. Um idTag diferente de BANCADA-DMAX é registrado como credencial candidata, pois também pode vir de RFID. O firmware precisa repassar esses dados à bancada.

Quando um campo aparece, o terminal registra `identificador de veículo observado` com o tipo, a origem e uma impressão digital. Mantenha a mesma janela da bancada aberta para comparar duas sessões do mesmo carro e uma de outro carro. A chave muda ao reiniciar o programa. A impressão não participa da autorização ou do controle de potência. No encerramento, `identificador de veículo não observado` indica que a bancada não viu um campo reconhecido associado àquela sessão.

## Comparar a atualização de perfil no Riseon

Com a recarga encerrada e o conector 1 em Preparing, habilite apenas uma potência autorizada. Para um ensaio de 5 para 10 kW, use `arm 10` e depois um dos comandos:

- `compare igual 5 10` usa o mesmo ID e nível do perfil inicial.
- `compare novo 5 10` usa outro ID e mantém o mesmo nível.
- `compare prioridade 5 10` usa outro ID e nível 2.
- `compare relativo 5 10` mantém o mesmo ID e nível e envia a atualização como TxProfile Relative, sem startSchedule. O período de zero do perfil relativo é contado a partir do início da transação.

Cada comando é um ensaio independente. A bancada abre uma transação nova com o perfil inicial (ID 200002, nível 1) e pede a troca após confirmar 5 kW. Antes e depois da troca registra `plano comparativo` com a resposta do GetCompositeSchedule. A rejeição da consulta deixa o plano inconclusivo, mas a medição segue. A bancada só confirma 10 kW com três amostras novas na faixa de 8,5 a 11,5 kW. Ao confirmar o segundo degrau ou expirar o prazo, solicita zero no ID e nível utilizados na última atualização e encerra a transação. A opção compare aceita no máximo 10 kW.

Confira a parada no painel e arme o teto novamente antes de outro modo. Use o mesmo carro e conector para comparar as leituras. Os modos são experimentais, dependem do firmware e não alteram a configuração do D-Max de produção.

## Ajuste manual na mesma recarga

Com o carro em Preparing, use `arm 10` e depois `start 5`, um comando por linha. Assim que aparecer a primeira medição da transação, digite `10` para pedir 10 kW com o perfil atual. Para testar outro formato, use `relativo 10`, `novo 10`, `prioridade 10` ou `igual 10`. Após usar nível 2, os próximos ajustes manuais mantêm pelo menos esse nível para não deixar um perfil anterior acima do pedido atual. O log mostra o ID, o nível e o tipo efetivamente enviados.

O modo manual segue com a transação aberta quando confirma um alvo ou quando ele fica sem confirmação por 45 segundos. Use `stop` para encerrar. A bancada ainda solicita parada em caso de falha ou perda de telemetria e ao sair com `quit`. Os perfis incluem zero programado aos 90 segundos, contado do horário do perfil absoluto ou do início da transação para perfil relativo. A potência pode cair antes de `stop` se o Riseon aplicar esse zero. A bancada não renova a potência sozinha. Compare, ramp e cycle continuam sendo ensaios automáticos e encerram ao concluir.

## Diagnóstico de firmware e Smart Charging

Com o Riseon conectado e a recarga encerrada, digite `diag`. O comando consulta as capacidades de Smart Charging por GetConfiguration. Se ainda não tiver recebido a versão do firmware, a bancada pede uma BootNotification via TriggerMessage. Esse pedido solicita o envio da mensagem e não reinicia o carregador. Alguns firmwares rejeitam o pedido. Se a versão aparecer vazia, confira também o painel do Riseon e procure uma linha posterior de identificação do carregador. O comando não altera as configurações nem inicia recarga.

## Teste sem ID da transação dentro do perfil

O comando `semid 10` tenta enviar 10 kW como TxProfile Absolute para o conector 1, omitindo o campo opcional transactionId em csChargingProfiles. Só funciona se a bancada já acompanha uma transação ativa e recebe telemetria. O ID continua obrigatório no pedido RemoteStopTransaction. Para executar o comparativo automático a partir de 5 kW, use `arm 10` e `compare semid 5 10`. Esse modo verifica uma diferença de interoperabilidade e depende da resposta real do carregador.

Quando o carregador responde explicitamente Rejected a uma mudança manual após aceitar o perfil inicial, a bancada mantém a transação e restaura o último formato aceito para os próximos pedidos. Isso permite tentar outro ajuste sem nova partida. Se não houver resposta inequívoca ou se houver perda de telemetria, continua valendo a parada de proteção.
