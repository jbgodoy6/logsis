# Bancada OCPP do D-Max

Bancada independente para o Riseon S202, ID `car002`, conector 1 e OCPP 1.6 JSON. Use com o carregador e o veículo supervisionados e com acesso ao painel local.

## Iniciar no CMD

1. Encerre a recarga antes de trocar o servidor. Confirme o IP atual do carregador no painel ou na tabela DHCP. O último observado foi `192.168.100.141`. Confirme com `ipconfig` o IPv4 da interface do **Windows** na mesma rede. O Raspberry usava `192.168.100.183`.
2. Instale Python 3.10 ou mais recente, com o launcher `py` disponível no CMD. Extraia o ZIP e rode `iniciar.bat`. A primeira execução instala a dependência incluída no ZIP em `.venv`, sem acesso à internet. Mantenha a pasta `wheels` junto de `iniciar.bat`.
3. Configure no carregador `ws://IP_DO_WINDOWS:8080/ocpp/car002` e o subprotocolo `ocpp1.6`. A bancada valida caminho e subprotocolo sem Basic Authentication. Use só em rede privada isolada, sem redirecionar a porta para a internet. Se o firewall exigir uma regra, libere apenas TCP 8080 no perfil Privado com endereço remoto restrito ao IP confirmado do carregador.
4. Confira `status`, `cfg` e, se necessário, `sample 5`. A bancada lê o intervalo de volta e registra se corresponde ao pedido. `schedule` consulta o plano composto em W. Rejeições dessas consultas aparecem associadas à ação correspondente. A bancada não emite Reset nem limpa perfis.

## Ensaiar

- `arm 10` habilita até 10 kW nesta conexão. Defina o teto pela potência autorizada para a instalação durante o ensaio.
- `start 5` solicita partida com perfil inicial de 5 kW e aplica o perfil à transação recebida. O limite é enviado em W, com horário UTC terminado em `Z`. Use um conector por vez. A bancada aguarda até 60 segundos pela abertura da transação após o aceite.
- Aguarde **potência confirmada**. Após `start` ou `set`, a bancada abre uma janela de até 30 segundos para o próximo comando. `set 7.5` muda o alvo da transação em curso. `ramp 5 5 10` testa 5 e 10 kW. `cycle 5 10 30 3` alterna 5 e 10 kW três vezes, sustentando cada alvo por pelo menos 30 segundos após confirmação.
- Cada degrau requer três amostras válidas, distintas e posteriores ao aceite, após 2 segundos de acomodação. As leituras devem cobrir pelo menos 5 segundos no relógio do carregador e na recepção, com tolerância de ±15% do alvo de potência (por exemplo, 8,5 a 11,5 kW para 10 kW). O primeiro prazo de confirmação é de 45 segundos. A bancada aborta após 15 segundos sem potência recente, perda da transação ou conexão, falha ou saída da faixa durante a permanência de um ciclo.
- `stop` cancela o ensaio e solicita zero e encerramento. A bancada também faz isso ao terminar rampa ou ciclo, ao expirar a janela manual ou ao abortar. `quit` encerra o programa e solicita parada se houver ensaio ou transação. Confira no painel quando a parada ou o zero físico ficarem sem confirmação, especialmente se o WebSocket cair. O perfil da bancada prevê zero a partir de 90 segundos, condicionado à aplicação pelo firmware.
- Consulte o CSV e o JSONL em `logs`. Pedidos, respostas, potência medida e encerramento da transação aparecem como eventos separados. Os logs omitem idTags e mensagens OCPP brutas. O intervalo exibido usa os timestamps das leituras válidas de potência.

O carregador simulado cobre a lógica OCPP. Confira se o Riseon aplica os perfis, fornece `Power.Active.Import` total em W ou kW e honra a parada antes de usar degraus maiores.

## Testes

Na pasta da bancada com a dependência instalada, rode `python -m unittest -v`. Os testes sobem um carregador simulado via WebSocket em loopback, sem Raspberry, planilha ou equipamento físico.
