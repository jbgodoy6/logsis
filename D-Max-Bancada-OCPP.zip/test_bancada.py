import asyncio
import json
import logging
from collections import deque
import unittest
from datetime import timedelta
from unittest.mock import patch

from websockets.asyncio.client import connect
from websockets.asyncio.server import serve
from websockets.exceptions import InvalidStatus

import bancada as b


class Simulador(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.events = []
        self.requests = deque()
        self.bench = b.Bench(lambda event, **data: self.events.append((event, data)))
        logger = logging.Logger("simulador-websocket")
        logger.addHandler(logging.NullHandler())
        self.server = await serve(self.bench.handler, "127.0.0.1", 0, subprotocols=["ocpp1.6"], logger=logger)
        self.url = "ws://127.0.0.1:" + str(self.server.sockets[0].getsockname()[1])
        self.ws = await connect(self.url + "/ocpp/car002", subprotocols=["ocpp1.6"])
        self.addAsyncCleanup(self.cleanup)
        self.config = patch.multiple(b, SETTLE=0, SPAN=.05, FRESH=.6, TIMEOUT=.5)
        self.config.start()
        self.addCleanup(self.config.stop)
        self.assertEqual((await self.incoming("BootNotification", {}))["status"], "Accepted")

    async def cleanup(self):
        await self.ws.close()
        if self.bench.job:
            await asyncio.wait_for(self.bench.job, 2)
        self.server.close()
        await self.server.wait_closed()

    async def message(self):
        return json.loads(await asyncio.wait_for(self.ws.recv(), 2))

    async def incoming(self, action, body):
        await self.ws.send(json.dumps([2, "sim", action, body]))
        frame = await self.message()
        while frame[0] == 2:
            self.requests.append(frame)
            frame = await self.message()
        self.assertEqual(frame[:2], [3, "sim"])
        return frame[2]

    async def request(self, action, status="Accepted"):
        kind, key, received, body = self.requests.popleft() if self.requests else await self.message()
        self.assertEqual((kind, received), (2, action))
        await self.ws.send(json.dumps([3, key, {"status": status}]))
        return body

    async def power(self, value, *, stamp=None, tx=None):
        await self.incoming("MeterValues", dict(
            connectorId=1, transactionId=self.tx if tx is None else tx,
            meterValue=[dict(timestamp=(stamp or b.utc()).isoformat(),
                             sampledValue=[dict(measurand="Power.Active.Import", unit="kW", value=str(value))])],
        ))

    async def session(self):
        with self.assertRaises(ValueError):
            await self.bench.command("start 5")
        await self.bench.command("arm 15")
        await self.bench.command("start 5")
        body = await self.request("RemoteStartTransaction")
        self.assertEqual(body["chargingProfile"]["chargingSchedule"]["chargingRateUnit"], "W")
        start = dict(connectorId=1, idTag=b.ID_TAG)
        self.assertEqual((await self.incoming("StartTransaction", dict(start, connectorId=2)))["idTagInfo"]["status"], "Invalid")
        reply = await self.incoming("StartTransaction", start)
        self.tx = reply["transactionId"]
        await self.target(5000)
        for _ in range(3):
            await asyncio.sleep(.04)
            await self.power(5)
        for _ in range(10):
            if self.bench.manual:
                return
            await asyncio.sleep(.03)
        self.fail("A potência inicial não foi confirmada")

    async def target(self, watts):
        body = await self.request("SetChargingProfile")
        self.assertEqual(body["connectorId"], 1)
        p = body["csChargingProfiles"]
        self.assertEqual(p["transactionId"], self.tx)
        self.assertEqual(p["chargingSchedule"]["chargingSchedulePeriod"][0]["limit"], watts)

    async def stopped(self):
        await self.target(0)
        self.assertEqual((await self.request("RemoteStopTransaction"))["transactionId"], self.tx)
        await self.power(0)
        await self.incoming("StopTransaction", {"transactionId": self.tx})
        await asyncio.wait_for(self.bench.job, 2)
        self.assertIn(("verificação de parada", {"encerrada": True}), self.events)

    async def test_rampa_bloqueada_em_49(self):
        await self.session()
        await self.bench.command("ramp 10 5 15")
        await self.target(10000)
        for _ in range(5):
            await asyncio.sleep(.05)
            await self.power(4.9)
        await self.stopped()

    async def test_rampa_exige_amostras_novas_e_da_transacao(self):
        await self.session()
        await self.bench.command("ramp 10 5 15")
        old = b.utc() - timedelta(seconds=3)
        await self.target(10000)
        await self.power(10, stamp=old)
        await self.power(10, tx=self.tx + 1)
        stamp = b.utc()
        await self.power(10, stamp=stamp)
        await self.power(10, stamp=stamp)
        await self.power(10, stamp=stamp)
        with self.assertRaises(TimeoutError):
            await asyncio.wait_for(self.ws.recv(), .055)
        for _ in range(3):
            await asyncio.sleep(.04)
            await self.power(10)
        await self.target(15000)
        stop = asyncio.create_task(self.bench.command("stop"))
        await self.stopped()
        await stop

    async def test_ciclo(self):
        await self.session()
        await self.bench.command("cycle 5 10 1 1")
        for target in (5, 10):
            await self.target(target * 1000)
            for _ in range(14):
                await asyncio.sleep(.10)
                await self.power(target)
        await self.stopped()

    async def test_amostragem_lida_de_volta(self):
        task = asyncio.create_task(self.bench.command("sample 5"))
        self.assertEqual(await self.request("ChangeConfiguration", "RebootRequired"),
                         {"key": "MeterValueSampleInterval", "value": "5"})
        _, key, action, body = await self.message()
        self.assertEqual(action, "GetConfiguration")
        self.assertEqual(body, {"key": ["MeterValueSampleInterval"]})
        await self.ws.send(json.dumps([3, key, {"configurationKey": [
            {"key": "MeterValueSampleInterval", "value": "10"},
        ]}]))
        await task
        self.assertIn(("verificação da amostragem", {"solicitado_s": 5, "confirmado": False}), self.events)

    async def test_falha(self):
        await self.session()
        await self.incoming("StatusNotification", {"connectorId": 1, "status": "Faulted"})
        await self.stopped()

    async def test_desconexao_desarma(self):
        await self.session()
        await self.ws.close()
        await asyncio.wait_for(self.bench.job, 2)
        self.assertEqual(self.bench.ceiling, 0)
        self.assertTrue(any(event == "zero e parada não confirmados" for event, _ in self.events))

    async def test_consulta_rejeitada(self):
        task = asyncio.create_task(self.bench.command("schedule"))
        await self.request("GetCompositeSchedule", "Rejected")
        await task
        self.assertIn(("resposta", {"acao": "GetCompositeSchedule", "status": "Rejected"}), self.events)
        self.assertFalse(any(event == "ensaio abortado" for event, _ in self.events))

    async def test_id_e_subprotocolo(self):
        async with connect(self.url + "/ocpp/outro", subprotocols=["ocpp1.6"]) as ws:
            await ws.wait_closed()
            self.assertEqual(ws.close_code, 1008)
        with self.assertRaises(InvalidStatus):
            await connect(self.url + "/ocpp/car002")

    def test_unidades(self):
        self.assertEqual(b.watts("7,5"), 7500)
        self.assertEqual(b.watts("4.9"), 4900)
        for value in ("0", "-1", "NaN", "60.1", "0.0001"):
            with self.assertRaises(ValueError):
                b.watts(value)
