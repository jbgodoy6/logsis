const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const browser = await chromium.launch({executablePath:'/usr/bin/chromium', headless:true, args:['--no-sandbox']});
  const report = [];
  for (const width of [1920, 1440, 1366]) {
    const page = await browser.newPage({viewport:{width, height:1080}, deviceScaleFactor:1});
    const errors = [];
    page.on('pageerror', e => errors.push(String(e)));
    page.on('response', async r => {
      if (r.url().includes('/api/ds/query')) {
        try {
          const body = await r.json();
          for (const [key, value] of Object.entries(body.results || {})) {
            if (value.error) errors.push(`${key}: ${value.error}`);
          }
        } catch (e) { errors.push(String(e)); }
      }
    });
    await page.goto('http://127.0.0.1:3300/d/logsis-dse7420-v23-studio?orgId=1&kiosk', {waitUntil:'networkidle'});
    await page.getByText('186.42 kW', {exact:true}).first().waitFor({timeout:45000});
    for(const text of ['0.97','12345.6 h','284215.7 kWh','QTA / SINAIS NÃO HOMOLOGADOS']) {
      const box = await page.getByText(text,{exact:true}).first().boundingBox();
      if(!box || box.x < 0 || box.x + box.width > width) throw new Error(`Clipped ${text} at ${width}`);
    }
    await page.screenshot({path:path.join(__dirname,`../dist/grafana-v23-${width}.png`), fullPage:true});
    report.push({width, errors, invalidText:await page.getByText(/Field not found|Double click to set field|Query error/).count()});
    if(width===1920) {
      fs.writeFileSync(path.join(__dirname,'../runtime/page-text.txt'), await page.locator('body').innerText());
    }
    await page.getByText(/02 \/ INSTRUMENTAÇÃO COMPLETA — expandir/).first().click();
    await page.getByText('MDB56', {exact:true}).waitFor();
    await page.getByText('0.97', {exact:true}).last().waitFor();
    const channels = await page.getByText(/^MDB\d{2}$/).count();
    if(channels !== 56) throw new Error(`Expected 56 instrument labels, got ${channels}`);
    report[report.length-1].instrumentChannels = channels;
    if(width===1366) {
      await page.screenshot({path:path.join(__dirname,'../dist/grafana-v23-instrumentacao.png'),fullPage:true});
      await page.goto('http://127.0.0.1:3300/d/logsis-dse7420-v23-studio?orgId=1&kiosk&from=1767225600000&to=1767229200000',{waitUntil:'networkidle'});
      await page.getByText('###',{exact:true}).first().waitFor();
      if(await page.getByText('186.42 kW',{exact:true}).count()) throw new Error('Stale power shown in empty interval');
      report[report.length-1].emptyWindow='### without stale power';
      await page.screenshot({path:path.join(__dirname,'../dist/grafana-v23-sem-dados.png'),fullPage:true});
    }
    await page.close();
  }
  fs.writeFileSync(path.join(__dirname,'../dist/visual-validation.json'),JSON.stringify(report,null,2));
  await browser.close();
})().catch(e => {console.error(e); process.exit(1);});
