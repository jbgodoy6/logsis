"""Build the review dashboard from the untouched supplied V22."""
import copy
import csv
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[1]
source = json.loads(next((ROOT / 'source').glob('*.json')).read_text())
d = copy.deepcopy(source)
canvas = d['panels'][1]
root = canvas['options']['root']
elements = root['elements']
BG, SURFACE, LINE, INK, MUTED, CYAN, AMBER = '#080f19', '#101c2b', '#26384b', '#ecf3fa', '#a6b8cb', '#69d5ef', '#edbf75'

def element(name, kind, x, y, w, h, text='', field=None, color=INK, size=14, bg='transparent', align='left'):
    return {'name': name, 'type': kind,
            'placement': {'left': x, 'top': y, 'width': w, 'height': h, 'rotation': 0},
            'constraint': {'horizontal': 'left', 'vertical': 'top'},
            'config': {'text': {'mode': 'field', 'field': field, 'fixed': '###'} if field else {'fixed': text},
                       'color': {'fixed': color}, 'size': size, 'align': align, 'valign': 'middle'},
            'background': {'color': {'fixed': bg}},
            'border': {'color': {'fixed': 'transparent'}, 'width': 0}, 'links': []}

# Keep the native vector machinery. Rebuild only labels/telemetry and instrument layout.
overview = []
for i, e in enumerate(elements):
    if i >= 130 and i < 364:
        continue
    if e['name'].startswith(('Medida label', 'Dado GMG ')) and e['name'] != 'Dado GMG modo':
        continue
    if e['name'] in ['Torre legend', 'QTA texto', 'Medições label', 'Histórico', 'Identificação']:
        continue
    if e['name'].startswith('Dado QTA'):
        continue
    overview.append(e)
    c = e['config']
    c['size'] = 13 if e['type'] == 'text' else 20
    if e['type'] in ['text', 'metric-value']:
        c['color'] = {'fixed': MUTED if e['type'] == 'text' else INK}
    if e['type'] == 'metric-value':
        c['text']['fixed'] = '###'
    if e['name'] == 'Fundo grafite':
        e['placement']['height'] = 736
        e['background']['color']['fixed'] = BG
    if e['name'].startswith(('Painel ', 'Cabeçalho', 'Leituras fundo', 'Medições rede')):
        e['background']['color']['fixed'] = SURFACE
        e['border']['color']['fixed'] = LINE
    if e['name'].startswith('Friso'):
        e['background']['color']['fixed'] = CYAN if 'qta' not in e['name'] else AMBER
    if e['name'] == 'Marca':
        c['text']['fixed'] = 'SISTEL  /  LOGSIS'; c['size'] = 21; c['color']['fixed'] = INK
        c['align'] = 'left'
    if e['name'] == 'Título':
        c['text']['fixed'] = 'DSE7420  /  SUPERVISÃO DE ENERGIA'; c['size'] = 16
    if e['name'] == 'Sinal 4G label':
        c['text']['fixed'] = 'RSSI'; e['placement']['left'] = 1100
    if e['name'] == 'Dado Sinal GSM':
        e['placement'].update(left=1155, width=140); c['size'] = 16
    if e['name'] == 'Motor label':
        c['text']['fixed'] = 'MOTOR / ALTERNADOR'; c['size'] = 12
    if e['name'] == 'Modo texto':
        c['text']['fixed'] = 'MODO¹'
    if e['name'] == 'Dado GMG modo':
        c['size'] = 16
    if e['name'].startswith(('Dado QTA', 'Contato móvel')):
        c['color'] = {'fixed': AMBER}; c['size'] = 20
    if e['name'].startswith('Dado QTA'):
        # These duplicates intersected the vertical busbars.
        e['placement'].update(top=308, left=421 if 'rede' in e['name'] else 729, width=65, height=24)
    if e['name'].startswith(('Entrada vertical', 'Terminal ', 'Ligação ', 'Barramento ', 'Ponto comutação', 'Saída QTA')):
        e['background']['color']['fixed'] = '#8193a7'
    if e['name'].startswith('Estado contato'):
        e['placement'].update(top=238, left=422 if e['name'].endswith('0') else 745, width=40)
    if e['name'].startswith('Rede tensão valor'):
        c['size'] = 18
    if e['name'] == 'Resumo QTA':
        e['background']['color']['fixed'] = '#27251f'

overview += [element('QTA validação', 'text', 444, 474, 324, 21, 'QTA / SINAIS NÃO HOMOLOGADOS', color=AMBER, size=12)]
# Every phase label now agrees with the actual field. Large total power/FP below.
for n, (label, field) in enumerate([
    ('TENSÃO L1–N', 'MDB09'), ('TENSÃO L2–N', 'MDB10'), ('TENSÃO L3–N', 'MDB11'),
    ('FREQUÊNCIA', 'MDB08'), ('ROTAÇÃO', 'MDB07'), ('TEMP. MOTOR', 'MDB02'), ('PRESSÃO ÓLEO', 'MDB01')]):
    y = 155 + n * 47
    overview += [element('Resumo etiqueta ' + field, 'text', 1097, y, 182, 15, label, color=MUTED, size=10),
                 element('Resumo valor ' + field, 'metric-value', 1097, y + 16, 182, 28, field=field, size=22)]
overview += [element('Contexto temporal', 'text', 24, 530, 680, 22,
                     'LEITURAS DO PERÍODO SELECIONADO  /  NÃO CONFIRMAM ESTADO AO VIVO', color=AMBER, size=12),
             element('Última leitura label', 'text', 820, 530, 210, 22, 'ÚLTIMO REGISTRO NA JANELA', color=MUTED, size=11),
             element('Última leitura valor', 'metric-value', 1040, 530, 256, 22, field='ULTIMA_LEITURA', size=15)]
for n, (label, field, note) in enumerate([
    ('POTÊNCIA ATIVA TOTAL', 'MDB22', 'GERADOR / TOTAL TRIFÁSICO'),
    ('FATOR DE POTÊNCIA MÉDIO', 'MDB28', 'GERADOR / FP TOTAL'),
    ('HORÍMETRO', 'MDB36', 'ACUMULADO / HORAS'),
    ('ENERGIA ACUMULADA', 'MDB37', 'GERADOR / kWh')]):
    x = 20 + n * 324
    overview += [element('Indicador base ' + field, 'rectangle', x, 576, 310, 118, bg=SURFACE),
                 element('Indicador acento ' + field, 'rectangle', x, 576, 310, 2, bg=CYAN),
                 element('Indicador título ' + field, 'text', x+16, 588, 278, 18, label, color=MUTED, size=11),
                 element('Indicador valor ' + field, 'metric-value', x+16, 611, 278, 43, field=field, color=INK, size=32),
                 element('Indicador nota ' + field, 'text', x+16, 664, 278, 16, note, color=MUTED, size=10)]
overview += [element('Nota supervisão', 'text', 24, 707, 1264, 18,
                     '¹ Modo conforme mapeamento legado; confirmar no controlador. Instrumentação e históricos nas seções abaixo.', color=MUTED, size=11)]
root['elements'] = overview
root['placement']['height'] = 736
root['background']['color']['fixed'] = BG
canvas['gridPos']['h'] = 21
canvas['title'] = 'LOGSIS  /  Visão geral da instalação'
canvas['description'] = 'Valores mais recentes válidos dentro da janela selecionada, com horários possivelmente distintos por campo. QTA não homologado; desenho e cores não confirmam energização. Somente leitura.'
canvas['transparent'] = True

# Units are explicit fixed suffixes; no implicit W-to-kW conversion or hours-to-years.
defaults = canvas['fieldConfig']['defaults']
defaults.update(noValue='###', color={'mode': 'fixed', 'fixedColor': INK})
overrides = canvas['fieldConfig']['overrides']
def override(field, properties):
    existing = next((v for v in overrides if v['matcher']['options'] == field), None)
    if existing is None:
        existing = {'matcher': {'id': 'byName', 'options': field}, 'properties': []}; overrides.append(existing)
    props = {p['id']: p['value'] for p in existing['properties']}; props.update(properties)
    existing['properties'] = [{'id': k, 'value': v} for k, v in props.items()]

for n in range(1, 57):
    field = f'MDB{n:02}'
    unit, decimals = 'none', 0
    if n == 1: unit, decimals = 'suffix: bar', 2
    elif n in [2, 3]: unit = 'suffix: °C'
    elif n == 4: unit = 'suffix: %'
    elif n in [5, 6] or 9 <= n <= 14 or 30 <= n <= 35: unit, decimals = 'suffix: V', 1
    elif n == 7: unit = 'suffix: rpm'
    elif n in [8, 29]: unit, decimals = 'suffix: Hz', 1
    elif 15 <= n <= 18: unit, decimals = 'suffix: A', 1 if n != 18 else 0
    elif 19 <= n <= 24: unit, decimals = 'suffix: '+('kW' if n <= 22 else 'kVA' if n == 23 else 'kVAr'), 2
    elif 25 <= n <= 28: decimals = 2
    elif n in [36, 39, 40, 41, 42]: unit, decimals = 'suffix: h', 1
    elif n == 37: unit, decimals = 'suffix: kWh', 1
    override(field, {'unit': unit, 'decimals': decimals})
for n in [55, 56]:
    override(f'MDB{n}', {'mappings': [
        {'type': 'value', 'options': {'0': {'text': '━', 'color': AMBER}, '1': {'text': '┃', 'color': AMBER}}},
        {'type': 'range', 'options': {'from': -1e30, 'to': -0.000001, 'result': {'text': '###', 'color': MUTED}}},
        {'type': 'range', 'options': {'from': 1.000001, 'to': 1e30, 'result': {'text': '###', 'color': MUTED}}},
        {'type': 'special', 'options': {'match': 'null', 'result': {'text': '###', 'color': MUTED}}}
    ]})
override('GSM_RSSI', {'unit': 'none', 'decimals': 0})
# Keep original SQL scales; tighten only QTA discrete domain. Fractional invalid values -> null.
sql = canvas['targets'][0]['rawSql']
for n in [55, 56]:
    pattern = rf'\(SELECT CASE WHEN mdb{n}.*?AS "MDB{n}"'
    sql = re.sub(pattern, f'(SELECT CASE WHEN mdb{n} IN (0, 1) THEN mdb{n} ELSE NULL END FROM $Id_Logsis WHERE $__timeFilter("time") ORDER BY "time" DESC LIMIT 1) AS "MDB{n}"', sql)
canvas['targets'][0]['rawSql'] = sql

# A separate collapsible section keeps the main installation at a readable scale.
instrument = copy.deepcopy(canvas)
instrument.update(id=2, title='Instrumentação / 56 canais', gridPos={'x': 0, 'y': 23, 'w': 24, 'h': 59})
instrument['options']['root']['placement']['height'] = 1712
ie = [element('Fundo instrumentação', 'rectangle', 0, 0, 1321, 1712, bg=BG)]
labels = {int(e['name'].split('MDB')[1]): e['config']['text']['fixed'].split('·')[0].strip() for e in elements if e['name'].startswith('Rótulo MDB')}
y = 16
for title, numbers, accent in [
    ('01 / MOTOR E COMBUSTÍVEL', range(1, 8), CYAN),
    ('02 / GERADOR — GRANDEZAS ELÉTRICAS', range(8, 29), CYAN),
    ('03 / CONCESSIONÁRIA', range(29, 36), CYAN),
    ('04 / OPERAÇÃO E MANUTENÇÃO', range(36, 43), CYAN),
    ('05 / MODO, ALARMES, ENTRADAS E QTA', range(43, 57), AMBER)]:
    ie += [element(title, 'text', 24, y, 1272, 24, title, color=accent, size=15)]
    y += 37
    for j, n in enumerate(numbers):
        x, yy = 20 + j % 4 * 324, y + j // 4 * 78
        f = f'MDB{n:02}'
        label = labels[n].replace('(kW)', '').replace('(kVA)', '').replace('(kVAr)', '').replace('(h)', '').replace('(kWh)', '').strip()
        ie += [element('Base '+f, 'rectangle', x, yy, 310, 70, bg=SURFACE),
               element('Canal '+f, 'text', x+12, yy+8, 52, 16, f, color=accent, size=10),
               element('Rótulo '+f, 'text', x+69, yy+7, 229, 18, label, color=MUTED, size=11),
               element('Valor '+f, 'metric-value', x+12, yy+30, 286, 32, field=f, color=INK, size=24)]
    y += ((len(numbers)+3)//4)*78 + 18
ie += [element('Nota canais', 'text', 24, y, 1272, 25,
               'QTA não homologado. Alarmes e entradas exibem códigos brutos; polaridade e bits dependem do controlador.', color=AMBER, size=12)]
instrument['options']['root']['elements'] = ie
instrument['options']['root']['placement']['height'] = y+48
ie[0]['placement']['height'] = y+48
instrument['gridPos']['h'] = (y+48+29)//30
d['panels'][0]['title'] = '01 / SUPERVISÃO DA INSTALAÇÃO'
historical = d['panels'][2]
historical['gridPos']['y'] = 24
historical['title'] = '03 / HISTÓRICOS LEGADOS — alarmes a revisar'
d['panels'] = [d['panels'][0], canvas,
               {'id': 902, 'type': 'row', 'title': '02 / INSTRUMENTAÇÃO COMPLETA — expandir', 'collapsed': True,
                'gridPos': {'x': 0, 'y': 22, 'w': 24, 'h': 1}, 'panels': [instrument]}, historical]
d.update(title='LOGSIS / DSE7420 — V23 Studio', uid='logsis-dse7420-v23-studio', id=None, version=1,
         tags=['LOGSIS', 'DSE7420', 'V23', 'supervisão'], description='Supervisório de leitura / V23 Studio. Visão geral, instrumentação completa e 13 históricos preservados da V22. QTA depende de homologação no equipamento.', graphTooltip=1)
d['timepicker']['refresh_intervals'] = ['30s', '1m', '5m', '15m', '30m', '1h']
for panel in [canvas, instrument]:
    panel['options'].update(panZoom=False, infinitePan=False)
    for e in panel['options']['root']['elements']:
        e['constraint'] = {'horizontal': 'left', 'vertical': 'top'}
out = ROOT / 'dist' / 'logsis_dse7420_v23_studio.json'
out.write_text(json.dumps(d, ensure_ascii=False, indent=2)+'\n')

# Audit the actual SQL, rather than repeating the contradictory supplied CSV scales.
with (ROOT / 'dist' / 'auditoria_56_canais.csv').open('w') as fp:
    w = csv.writer(fp, delimiter=';'); w.writerow(['campo', 'rotulo', 'expressao_sql', 'unidade', 'decimais', 'validacao'])
    for n in range(1,57):
        f=f'MDB{n:02}'; line=next(l.strip().rstrip(',') for l in sql.splitlines() if f'AS "{f}"' in l)
        props={p['id']:p['value'] for o in overrides if o['matcher']['options']==f for p in o['properties']}
        w.writerow([f, labels[n], line, props['unit'], props['decimals'], 'SQL/JSON; escala física não homologada'])
print(out)
