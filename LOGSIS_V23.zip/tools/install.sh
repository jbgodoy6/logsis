#!/usr/bin/env bash
set -euo pipefail
cd /workspace/logsis-design
test -f source/sistel_logsis_dse7420_v22_potencia_fp_totais.json
docker pull grafana/grafana:11.2.2@sha256:d5133220d770aba5cb655147b619fa8770b90f41d8489a821d33b1cd34d16f89
docker pull postgres:16-alpine@sha256:deb28ee471183cb0c303113dac9b2433c51eeeeb678def7af9a9ec5820367815
npm install --prefix tools --cache /workspace/logsis-design/runtime/npm-cache --no-audit --no-fund --package-lock=false playwright@1.56.1
python tools/build_dashboard.py
