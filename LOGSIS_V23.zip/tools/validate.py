"""Regression and live Grafana SQL checks against synthetic PostgreSQL only."""
import copy
import datetime
import json
import pathlib
import re
from lab import api, psql

ROOT=pathlib.Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'dist/logsis_dse7420_v23_studio.json').read_text())
original=json.loads(next((ROOT/'source').glob('*.json')).read_text())
results=[]
def check(name, test):
    assert test, name
    results.append({'check':name,'status':'passed'})

check('13 painéis históricos preservados integralmente',len(d['panels'][3]['panels'])==13 and d['panels'][3]['panels']==original['panels'][2]['panels'])
for p in [d['panels'][1], d['panels'][2]['panels'][0]]:
    r=p['options']['root']
    check('Todos elementos dentro da altura: '+p['title'], all(e['placement']['top']+e['placement']['height']<=r['placement']['height'] for e in r['elements']))
    sql=p['targets'][0]['rawSql']
    aliases=set(re.findall(r'AS "([A-Z_0-9]+)"',sql))
    check('Vínculos Canvas existem no SQL: '+p['title'],all(e['config']['text']['field'] in aliases for e in r['elements'] if e['type']=='metric-value'))
check('56 canais individuais', {e['config']['text']['field'] for e in d['panels'][2]['panels'][0]['options']['root']['elements'] if e['type']=='metric-value'}=={f'MDB{i:02}' for i in range(1,57)})

sql=d['panels'][1]['targets'][0]['rawSql'].replace('$Id_Logsis','id_255880306351140').replace('$__timeFilter("time")', '"time" BETWEEN \'2026-01-01T00:00:00Z\' AND \'2026-01-01T01:00:00Z\'')
common='BEGIN; CREATE TEMP TABLE id_255880306351140 (LIKE public.id_255880306351140); '
def scenario(setup):
    out=psql(common+setup+' SELECT row_to_json(q) FROM ('+sql+') q; ROLLBACK;')
    return json.loads(next(l for l in out.splitlines() if l.startswith('{')))

empty=scenario('')
check('Janela vazia retorna null nos 56 canais', all(empty[f'MDB{i:02}'] is None for i in range(1,57)))
r=scenario("INSERT INTO id_255880306351140(time,mdb22,mdb28,mdb36,mdb39,mdb55,mdb56) VALUES ('2026-01-01T00:30Z',186420,97,44444160,720000,0,1);")
check('Potência acima de 32760 não descartada /1000', r['MDB22']==186.42)
check('FP /100',r['MDB28']==0.97)
check('Horímetro e manutenção /3600', r['MDB36']==12345.6 and r['MDB39']==200)
check('QTA aceita 0/1',r['MDB55']==0 and r['MDB56']==1)
r=scenario("INSERT INTO id_255880306351140(time,mdb22,mdb9,mdb55,mdb56) VALUES ('2025-12-31T23:00Z',999999,999,1,1),('2026-01-01T00:10Z',-50000,2200,0,1),('2026-01-01T00:20Z',null,32763,-1,0.5);")
check('Potência negativa preservada',r['MDB22']==-50)
check('Último valor válido e filtro legado de tensão',r['MDB09']==220)
check('QTA inválido mais recente não recua para estado antigo',r['MDB55'] is None and r['MDB56'] is None)
r=scenario("INSERT INTO id_255880306351140(time,mdb22) VALUES ('2025-12-31T23:00Z',100000);")
check('Sem preenchimento com dado fora da janela',r['MDB22'] is None)

now=datetime.datetime.now(datetime.timezone.utc)
for panel in [d['panels'][1], *d['panels'][3]['panels']]:
    targets=[]
    for t in panel.get('targets',[]):
        if not t.get('rawSql'): continue
        q=copy.deepcopy(t)
        q['rawSql']=q['rawSql'].replace('$Id_Logsis','id_255880306351140')
        q['datasource']={'uid':'zKW_ld27k','type':'grafana-postgresql-datasource'}
        q.update(intervalMs=30000,maxDataPoints=1000)
        targets.append(q)
    if not targets: continue
    response=api('/api/ds/query', {'queries':targets,'from':str(int((now.timestamp()-86400)*1000)),'to':str(int(now.timestamp()*1000))})
    check('Grafana executa SQL: '+panel['title'],all(not v.get('error') and v.get('frames') for v in response['results'].values()))
(ROOT/'dist/validation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(f'{len(results)} verificações aprovadas. Dados exclusivamente sintéticos.')
