#!/usr/bin/env bash
set -euo pipefail
cd /workspace/logsis-design
docker network inspect logsis-lab >/dev/null 2>&1 || docker network create logsis-lab
if ! docker container inspect logsis-postgres >/dev/null 2>&1; then
  docker run -d --name logsis-postgres --network logsis-lab \
    -e POSTGRES_HOST_AUTH_METHOD=trust -e POSTGRES_DB=logsis \
    postgres:16-alpine@sha256:deb28ee471183cb0c303113dac9b2433c51eeeeb678def7af9a9ec5820367815
else
  docker start logsis-postgres >/dev/null
fi
if ! docker container inspect logsis-grafana >/dev/null 2>&1; then
  docker run -d --name logsis-grafana --network logsis-lab -p 127.0.0.1:3300:3000 \
    -e GF_AUTH_ANONYMOUS_ENABLED=true -e GF_AUTH_ANONYMOUS_ORG_ROLE=Admin \
    -e GF_AUTH_DISABLE_LOGIN_FORM=true -e GF_ANALYTICS_REPORTING_ENABLED=false \
    -e GF_ANALYTICS_CHECK_FOR_UPDATES=false \
    grafana/grafana:11.2.2@sha256:d5133220d770aba5cb655147b619fa8770b90f41d8489a821d33b1cd34d16f89
else
  docker start logsis-grafana >/dev/null
fi
python - <<'PY'
import subprocess,time,urllib.request
for attempt in range(30):
    pg=subprocess.run(['docker','exec','logsis-postgres','pg_isready','-U','postgres'],capture_output=True).returncode==0
    try:
        with urllib.request.urlopen('http://127.0.0.1:3300/api/health',timeout=2) as r:
            gf=r.status==200
    except Exception:
        gf=False
    if pg and gf: break
    time.sleep(1)
else: raise SystemExit('Grafana/PostgreSQL did not become ready')
PY
# Dedicated synthetic lab only: resets its fixture, never a production datasource.
python tools/lab.py
python tools/validate.py
