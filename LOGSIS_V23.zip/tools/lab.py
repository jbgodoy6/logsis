"""Local isolated lab: synthetic data only; never connects to production."""
import datetime
import json
import pathlib
import subprocess
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
URL = 'http://127.0.0.1:3300'
def api(path, data=None):
    req = urllib.request.Request(URL+path, data=json.dumps(data).encode() if data is not None else None,
                                 headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req) as r: return json.load(r)

def psql(sql):
    r = subprocess.run(['docker','exec','-i','logsis-postgres','psql','-U','postgres','-d','logsis','-X','-v','ON_ERROR_STOP=1','-At'],
                       input=sql, text=True, capture_output=True, check=True)
    return r.stdout.strip()

if __name__ == '__main__':
    fields = ', '.join(f'mdb{i} numeric' for i in range(1,57))
    psql(f'CREATE TABLE IF NOT EXISTS id_255880306351140 (time timestamptz, gsm_rssi numeric, {fields});')
    vals={1:450, 2:82, 3:88, 4:76, 5:278, 6:274, 7:1800, 8:600, 18:0, 22:186420, 23:192186, 24:46780,
          29:600, 36:44444160, 37:2842157, 38:286, 39:720000, 40:360000, 41:1080000, 42:1800000,43:2,55:-1,56:-1}
    vals.update({i: v for i,v in zip(range(9,18),[2201,2206,2198,3810,3820,3802,2840,2820,2850])})
    vals.update({i:62140 for i in range(19,22)})
    vals.update({i:97 for i in range(25,29)})
    vals.update({i:v for i,v in zip(range(30,36),[2202,2207,2199,3811,3821,3803])})
    psql('TRUNCATE id_255880306351140; INSERT INTO id_255880306351140 SELECT now()-make_interval(mins=>i),22,'+
         ','.join(str(vals.get(i,0)) for i in range(1,57))+' FROM generate_series(0,120) AS s(i);')
    ds={'name':'LOGSIS — laboratório sintético', 'uid':'zKW_ld27k', 'type':'grafana-postgresql-datasource',
        'url':'logsis-postgres:5432','user':'postgres','database':'logsis','access':'proxy',
        'jsonData':{'database':'logsis','sslmode':'disable','postgresVersion':1600,'timescaledb':False}}
    # sslmode=disable applies only to this isolated Docker lab, never remote TLS connections.
    try: api('/api/datasources/uid/zKW_ld27k')
    except urllib.error.HTTPError: api('/api/datasources',ds)
    d=json.loads((ROOT/'dist/logsis_dse7420_v23_studio.json').read_text())
    print(api('/api/dashboards/db', {'dashboard':d, 'overwrite':True, 'message':'V23 synthetic validation'}))
