# MEMÓRIA TÉCNICA — LOGSIS / DSE7420 / GRAFANA

**Transferência para Codex — 22/10/2026**

Documento de continuidade do desenvolvimento. Fonte: histórico de decisões desta conversa, arquivo BIN auditado, CSV de auditoria e inspeção direta do JSON V22. **Não equivale a teste em hardware/Grafana**.


## 1. Objetivo e ambiente
- SCADA/HMI para grupo gerador Deep Sea **DSE7420**, com supervisão LOGSIS.
- **Grafana 11.2.2**, PostgreSQL, datasource UID `zKW_ld27k`.
- Tabela dinâmica PostgreSQL via variável constante Grafana `$Id_Logsis` (V22: `id_255880306351140`).
- Dados nas colunas `mdb1`…`mdb56`, `gsm_rssi`, `time`.
- Entrega em **um JSON importável**, sem dependência de imagens locais; usar Canvas vetorial nativo.
- Dashboard atual de referência: `sistel_logsis_dse7420_v22_potencia_fp_totais.json`. Tratar como **baseline de trabalho, não versão final homologada**.


## 2. Regras funcionais obrigatórias
1. **Último valor dentro do período escolhido:** cada MDB busca o registro válido mais recente com `$__timeFilter("time")`, `ORDER BY "time" DESC LIMIT 1`. Nunca buscar valor fora da janela para preencher um vazio. Exibir `###` para ausência/invalidez, sem interpretar como zero.
2. **Potências MDB19–24:** dividir bruto por **1000**, sem descartar por limiar de estouro `32760`. MDB19/20/21 são fases L1/L2/L3; MDB22 ativa total kW; MDB23 aparente total kVA; MDB24 reativa total kVAr. Na planta principal, **potência = MDB22**.
3. **Fatores de potência MDB25–28:** dividir por **100**; fases L1/L2/L3 e FP médio MDB28. Na planta principal, **FP = MDB28**. Exibir duas ou três casas conforme precisão necessária, sem converter `0,97` para `97`.
4. **Horímetro e horas de manutenção MDB36 e MDB39–42:** valor bruto em segundos, dividir **sempre por 3600**, arredondar para **uma casa decimal** e usar **sufixo fixo `h`**, nunca unidade Grafana de duração que transforme em `years`. Sem filtro de estouro `32760`.
5. **Demais grandezas:** filtro de estouro legado em ±32760 foi usado, mas deve ser validado por variável, especialmente leituras 32-bit. Não assumir que `32763` ou `65531` sempre significam erro em todas as grandezas.
6. **Tensões gerador:** MDB09–11 = L1–N, L2–N, L3–N; MDB12–14 = L1–L2, L2–L3, L3–L1. **MDB14 imediatamente após MDB13**, nunca na seção motor ou oculto.
7. **Tensões concessionária:** MDB30–32 = L1–N/L2–N/L3–N; MDB33–35 = L1–L2/L2–L3/L3–L1; MDB29 frequência.
8. **QTA:** MDB55 contato rede, MDB56 contato GMG, interpretação pretendida 0 aberto (traço horizontal), 1 fechado (vertical); 1/1 sinalizar anomalia. **PENDÊNCIA CRÍTICA:** no BIN auditado MDB55/56 estão `-1` (não configurados), portanto não validar a animação sem confirmar BIN de produção e sinais reais.
9. **Entradas digitais:** MDB47–54 (A–H), rótulos personalizados por Editor/Admin. Na V22 a alteração é feita editando o dashboard, **não** existe editor operacional com gravação persistente ou escrita Modbus.
10. **Históricos:** preservar curvas originais e alarmes, em seção recolhível no mesmo JSON, dispostos um abaixo do outro; não acrescentar séries arbitrárias. O JSON V22 contém **13 painéis na seção recolhida**, contagem a conferir com a versão original.


## 3. Ordem visual da instrumentação
- Motor/combustível: MDB01–07 e estados somente onde semanticamente adequados.
- Grandezas elétricas GMG em ordem numérica contínua: MDB08…MDB28, grade de quatro colunas, preenchimento linha a linha.
- Rede: MDB29…MDB35.
- Horas/energia/partidas/manutenção: MDB36…MDB42.
- Modo, alarmes, entradas e QTA: MDB43…MDB56.
- Evitar elementos encobertos por fundos: Canvas depende da ordem de renderização. O 'buraco' da MDB14 na V20 foi atribuído à sobreposição de fundo, ajustado na V21.
- Estilo solicitado: SCADA industrial técnico e sóbrio, sem 'blocos artificiais', sem sobreposição de rótulos/valores, espaços compactos, torre treliçada, gerador detalhado, QTA unifilar e sinal 4G.


## 4. Histórico de aprendizado / evolução
- V1–V5: protótipos Canvas e imagem; imagens externas ou Base64 não confiáveis para distribuição a clientes.
- V6–V9: planta vetorial nativa; correções de cortes, espaços e retorno aos gráficos originais.
- V10–V11: separação lógica supervisório/histórico; **um único JSON** com seções recolhíveis (Grafana não oferece abas nativas neste formato).
- V12–V13: estética slim/técnica; usuário rejeitou visual de retângulos simples; versão técnica melhorou silhuetas e organização.
- V14: ícones, cartões, filtro temporal; corrigir sobreposição de leituras.
- V15–V18: revisões de potências, horímetros, tensões FN/FF, QTA e rótulos de entradas. Houve regressões: horímetro sem /3600 e unidade `years`, depois corrigidos.
- V19: auditoria BIN revelou MDB14 tensão L3–L1, MDB18 corrente terra, MDB25–28 FP por fase/médio, MDB55–56 não configuradas no BIN auditado.
- V20–V21: ordenar MDB08–28; corrigir elemento MDB14 encoberto.
- V22: indicadores **na planta principal** potência MDB22 total e FP MDB28 médio; manter demais grandezas e curvas.


## 5. Situação observada e riscos
- Capturas mostraram `###` em massa após alterações, **não resolvido de forma conclusiva**; verificar se consultas estão retornando dados no período, vinculação Canvas e override de campos.
- BIN e JSON podem divergir do controlador em produção; os rótulos auditados vêm do BIN, e as escalas do SQL V22. Não tratar essas duas fontes como validação do protocolo físico.
- No JSON V22, o painel Canvas possui **uma consulta SQL `format=table`** que produz colunas `MDB01`…`MDB56`, `GSM_RSSI`, `ULTIMA_LEITURA`. Há dois painéis tipo `row`, sendo o histórico recolhido com 13 painéis internos.
- Os elementos Canvas V22 não possuem links clicáveis configurados (`links` vazios). O texto de 'CURVAS' não é necessariamente botão funcional; a navegação comprovada é expandir/recolher a seção.
- A representação dinâmica do QTA via mapeamento de caracteres deve ser testada visualmente; não assumir animação/rotação nativa validada.
- **Segurança operacional:** a tela deve distinguir leitura histórica de estado atual; um QTA mostrado no período passado não é confirmação da posição presente. Em caso de ausência de dados, não indicar energização.
- Avaliar performance de 56 subconsultas correlatas independentes por atualização; índice de tempo, retenção e política de atualização são assuntos de engenharia pendentes.


## 6. Plano de testes para Codex
1. Importar V22 em Grafana 11.2.2 **como novo dashboard**, sem substituir produção.
2. Validar datasource UID, expansão `$Id_Logsis`, retorno SQL e intervalo temporal com amostras recentes e antigas.
3. Testar os 56 campos individualmente: rótulo, endereço, função, escala, precisão, nulidade, unidade, cor e visibilidade.
4. Confirmar MDB09–14 e MDB30–35 em tensão fase-neutro e fase-fase com medidas reais.
5. Validar potências (incluindo valores brutos >32760 e negativos), FP total MDB28 e conversão de horas `/3600` com 1 decimal e sufixo literal `h`.
6. Testar todas as quatro combinações MDB55/56; **somente após** confirmar endereço real dos dois sinais.
7. Testar resolução de 1366/1440/1920 px, zoom, cortes, sobreposições e expansão/recolhimento de históricos.
8. Confirmar que os gráficos correspondem às curvas do JSON original e não sofreram mudança de consulta.
9. Testar permissões Viewer, Editor e Admin para edição dos rótulos das entradas; não implementar escrita remota sem autorização e projeto de segurança.
10. Documentar evidências (captura + valor SQL bruto + valor calculado + referência BIN) e bloquear regressões.


## 7. Prompt pronto para o Codex
> Use o arquivo `sistel_logsis_dse7420_v22_potencia_fp_totais.json` como baseline e `LOGSIS_DSE7420_MAPEAMENTO_TECNICO.csv` como referência de nomes e endereços do BIN. Leia integralmente esta memória técnica antes de alterar código. Faça auditoria automatizada dos 56 campos, escalas, rótulos, layout e vínculo dos elementos Canvas com os campos SQL. Corrija os defeitos sem recriar o dashboard do zero nem modificar curvas originais. Garanta última leitura dentro do intervalo do Grafana, potências MDB19–24 /1000 sem filtro de estouro, horímetros MDB36/MDB39–42 /3600 com uma decimal e sufixo fixo h, FP MDB25–28 /100, e indicadores principais MDB22/MDB28. Mantenha ordem MDB08–MDB28 sem buracos e tensões L–N/L–L corretas. Identifique explicitamente o que é comprovado pelo BIN, pelo JSON e o que depende de teste no equipamento. Gere JSON corrigido, relatório de diferenças e roteiro de validação. Não invente estados do QTA: MDB55/56 estão sem endereço no BIN auditado.
