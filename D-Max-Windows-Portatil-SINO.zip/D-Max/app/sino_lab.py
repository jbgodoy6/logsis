"""Supervised, local-only SINO commissioning screen for a direct Ethernet link."""
from collections import deque
from decimal import InvalidOperation
from pathlib import Path
from types import SimpleNamespace

from fastapi import Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .sino_bench import Bench, Log


class Command(BaseModel):
    command: str = Field(min_length=1, max_length=40)


class Link:
    def __init__(self, ws):
        self.ws = ws
        self.request = SimpleNamespace(path=ws.url.path)
        self.remote_address = (ws.client.host, ws.client.port)
        self.subprotocol = 'ocpp1.6'

    def __aiter__(self):
        return self.ws.iter_text()

    async def send(self, message):
        try:
            await self.ws.send_text(message)
        except WebSocketDisconnect as exc:
            raise RuntimeError('Conexão encerrada') from exc

    async def close(self, code):
        await self.ws.close(code)


def install(app, address, log_dir, administrator):
    history = deque(maxlen=80)
    print_log = Log(log_dir)

    def log(event, **data):
        print_log(event, **data)
        history.append({'evento': event, **data})

    bench = Bench(log)
    app.state.sino_lab = bench

    async def local(request: Request, account=Depends(administrator)):
        if (not request.client or request.client.host not in ('127.0.0.1', '::1')
                or request.url.hostname not in ('localhost', '127.0.0.1', '::1')):
            raise HTTPException(403, 'Abra a bancada no próprio computador')

    @app.get('/bancada-sino', dependencies=[Depends(local)])
    async def page():
        path = Path(__file__).parent / 'static/sino-lab.html'
        return FileResponse(path, headers={'X-DMax-Live': '1', 'Cache-Control': 'no-store'})

    @app.get('/api/bancada-sino', dependencies=[Depends(local)])
    async def status():
        return {'conectado': bench.ws is not None, 'estado': bench.status, 'transacao': bench.tx,
                'teto_w': bench.ceiling, 'potencia_w': bench.sample[2] if bench.sample and bench.tx is not None else None,
                'eventos': list(history)}

    @app.post('/api/bancada-sino', dependencies=[Depends(local)])
    async def command(data: Command, request: Request):
        if request.headers.get('origin') != str(request.base_url).rstrip('/'):
            raise HTTPException(403, 'Abra o painel local para enviar o comando')
        parts = data.command.strip().lower().split()
        if not parts or (parts[0] not in {'arm', 'startlivre', 'start', 'set', 'stop', 'diag', 'cfg'}
                         and not (len(parts) == 1 and parts[0][0].isdigit())):
            raise HTTPException(422, 'Use um dos comandos do painel')
        try:
            await bench.command(' '.join(parts))
        except (ValueError, InvalidOperation, RuntimeError, TimeoutError) as exc:
            raise HTTPException(409, str(exc) or 'O carregador não respondeu') from exc
        return {'ok': True}

    @app.websocket('/ocpp/car002')
    async def sino_ocpp(ws: WebSocket):
        if (not ws.client or ws.client.host != address or bench.ws is not None
                or 'ocpp1.6' not in ws.scope.get('subprotocols', [])):
            await ws.close(code=1008)
            return
        await ws.accept(subprotocol='ocpp1.6')
        await bench.handler(Link(ws))
