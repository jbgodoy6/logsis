'use strict';
const endpoint = '/api/bancada-sino';
const form = document.querySelector('#command');
const input = document.querySelector('#value');
const message = document.querySelector('#message');
const status = document.querySelector('#status');
const events = document.querySelector('#events');
const number = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 2 });

async function refresh() {
    try {
        const response = await fetch(endpoint, { cache: 'no-store' });
        if (!response.ok) throw new Error('Entre novamente no painel local do D-Max.');
        const data = await response.json();
        const kw = value => value === null ? 'Sem leitura' : number.format(value / 1000) + ' kW';
        const values = [
            ['Conexão', data.conectado ? 'Conectado' : 'Desconectado'],
            ['Conector 1', data.estado || 'Aguardando'],
            ['Transação', data.transacao ?? 'Aguardando partida'],
            ['Potência medida', kw(data.potencia_w)],
            ['Teto de ensaio', kw(data.teto_w)],
        ];
        status.replaceChildren();
        for (const [label, value] of values) {
            const term = document.createElement('dt');
            const detail = document.createElement('dd');
            term.textContent = label;
            detail.textContent = value;
            status.append(term, detail);
        }
        events.textContent = data.eventos.slice().reverse().map(({ evento, ...details }) =>
            evento + ' ' + JSON.stringify(details)).join('\n');
    } catch (error) {
        status.textContent = 'Sem atualização. ' + error.message;
    } finally {
        setTimeout(refresh, 1000);
    }
}

async function send(command) {
    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command }),
        });
        const result = await response.json();
        message.textContent = response.ok ? 'Comando recebido. Confira as medições e os eventos.' : result.detail;
        return response.ok;
    } catch (error) {
        message.textContent = 'Falha ao enviar. Confira a conexão e o painel do carregador.';
        return false;
    }
}

form.addEventListener('submit', async event => {
    event.preventDefault();
    if (await send(input.value)) input.value = '';
});
document.querySelector('#stop').addEventListener('click', () => send('stop'));
refresh();
