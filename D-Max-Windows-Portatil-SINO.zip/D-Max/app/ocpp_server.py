"""OCPP 1.6J adapter. A physical unit must be explicitly commissioned before admission."""
import asyncio
from datetime import datetime, timezone
import logging
import math
import re
import time

from ocpp.routing import on
from ocpp.v16 import ChargePoint, call, call_result
from ocpp.v16.enums import Action
from .control import blocked_at

# Raw OCPP frames can contain authorization identifiers. Persist selected events instead.
logging.getLogger('ocpp').setLevel(logging.WARNING)

EVID_WINDOW = 120
EVID_TOKEN = re.compile(r'(?:VID:)?(?:[0-9A-F]{12}|[0-9A-F]{16}|[0-9A-F]{2}(?:[:-][0-9A-F]{2}){5}(?:(?:[:-][0-9A-F]{2}){2})?)', re.ASCII | re.I)


def utc():
    return datetime.now(timezone.utc).isoformat()


class Socket:
    def __init__(self, ws):
        self.ws = ws

    async def recv(self):
        return await self.ws.receive_text()

    async def send(self, message):
        await self.ws.send_text(message)


class Station(ChargePoint):
    def __init__(self, identifier, socket, engine):
        super().__init__(identifier, socket, response_timeout=10)
        self.engine = engine
        self.sino = False
        self.evid_grant = None

    def port(self, number):
        return self.engine.ports.get(f'{self.id}:{number}')

    @on(Action.boot_notification)
    async def boot(self, charge_point_vendor, charge_point_model, **kwargs):
        firmware = kwargs.get('firmware_version') or ''
        sino_profileless = (str(charge_point_vendor).strip().upper() == 'SINO'
                            and str(charge_point_model).strip().upper() == 'PEVC3106E'
                            and str(firmware).strip().upper() == 'V1.20')
        self.sino = sino_profileless
        self.evid_grant = None
        for p in self.engine.ports.values():
            if p['charger'] == self.id:
                p['sino_profileless'] = self.sino and p['connector'] in (1, 2)
                p.update(firmware=kwargs.get('firmware_version') or '',serial=kwargs.get('charge_point_serial_number') or '')
                if p.get('test'):p['test']['interrupted']=True
                p.update(profile_initialized=False, sample_at=0, native_released=False, native_attempt=0)
                if not p.get('sino_start_pending'):
                    p['start_pending_at'] = 0
        self.engine.store.record('ocpp_boot', {'charger': self.id, 'vendor': charge_point_vendor,
                                             'model': charge_point_model, 'firmware': kwargs.get('firmware_version')})
        return call_result.BootNotification(current_time=utc(), interval=30, status='Accepted')

    @on(Action.heartbeat)
    async def heartbeat(self, **kwargs):
        return call_result.Heartbeat(current_time=utc())

    @on(Action.status_notification)
    async def status(self, connector_id, error_code, status, **kwargs):
        p = self.port(connector_id)
        affected = [p] if p else [q for q in self.engine.ports.values() if q['charger'] == self.id] if connector_id == 0 else []
        for target in affected:
            target['error_code'] = error_code
            if connector_id == 0:
                target['station_alarm'] = status == 'Faulted' or error_code != 'NoError'
                target['station_error_code'] = error_code
        if self.evid_grant and (
                (connector_id == self.evid_grant[0] and status in ('Available', 'Finishing', 'Faulted', 'Unavailable'))
                or (connector_id == 0 and status in ('Faulted', 'Unavailable'))):
            self.evid_grant = None
        if p:
            p['ocpp_status'] = status
            if status == 'Available':
                self.engine.disconnect(p['key'])
            elif status in ('Preparing', 'Charging', 'SuspendedEV', 'SuspendedEVSE'):
                if not p['connected']:
                    p.update(connected=True, arrival=time.time())
                if (status == 'Charging' and not p['running'] and not p.get('sino_start_pending')
                        and not (self.evid_grant and self.evid_grant[0] == connector_id
                                 and time.time() - self.evid_grant[2] < EVID_WINDOW)):
                    p['manual_pause'] = True
                    self.engine.store.record('reconciliation_required', {'port': p['key'], 'note': 'Sessão existente; aguardando MeterValues com transactionId'})
            self.engine.store.record('ocpp_status', {'port': p['key'], 'status': status, 'error': error_code})
        return call_result.StatusNotification()

    def authorize_evid(self, id_tag, config):
        # Authorize carries no connectorId. A running session already has its own transaction.
        ports = [p for p in self.engine.ports.values() if p['charger'] == self.id
                 and p['connected'] and not p['running'] and p['ocpp_status'] == 'Preparing']
        if (not self.sino or not EVID_TOKEN.fullmatch(id_tag) or len(id_tag) > 20
                or not config['enabled'] or not config['commissioned']
                or self.engine.store.settings()['mode'] != 'physical'):
            return False
        if len(ports) != 1:
            return False
        p = ports[0]
        if (not p.get('sino_profileless') or p['manual_pause']
                or p.get('station_alarm') or p.get('error_code', 'NoError') != 'NoError'):
            return False
        now = time.time()
        if self.evid_grant and 0 <= now - self.evid_grant[2] < EVID_WINDOW:
            return self.evid_grant[:2] == (p['connector'], id_tag)
        if p.get('sino_start_pending'):
            return False
        if not self.engine.subscription.status()['native']:
            settings = self.engine.store.settings()
            chargers = {c['id']: c for c in self.engine.store.entities('charger')
                        if c['transport'] == 'ocpp' and not c.get('archived')}
            active = [candidate for candidate in self.engine.ports.values() if candidate['charger'] in chargers]
            circuits = {c['id']: c['limit_kw'] for c in settings['circuits']}
            if config['rate_unit'] != 'W' or not self.engine.admit_sino(p, active, chargers, circuits, settings, shared_evid=True):
                return False
            p['sino_evid_pending'] = True
        self.evid_grant = (p['connector'], id_tag, now)
        return True

    @on(Action.authorize)
    async def authorize(self, id_tag, **kwargs):
        config = self.engine.config(self.id)
        if config.get('sino_evid'):
            accepted = self.authorize_evid(id_tag, config)
            self.engine.store.record('sino_evid_authorization', {'charger': self.id,
                                     'status': 'Accepted' if accepted else 'Blocked',
                                     'port': self.evid_grant[0] if accepted else None})
            return call_result.Authorize(id_tag_info={'status': 'Accepted' if accepted else 'Blocked'})
        # Autocharge identity alone is not permission to bypass the admission queue.
        # Bind only with an unambiguous pending connector. Authorize has no connectorId.
        candidates = [p for p in self.engine.ports.values() if p['charger'] == self.id
                      and p['connected'] and not p['running']]
        if len(candidates) == 1:
            self.engine.identify(candidates[0], id_tag)
        self.engine.store.record('authorization_observed', {'charger': self.id, 'identifier': id_tag,
                                                           'association': 'unambiguous' if len(candidates) == 1 else 'unknown'})
        reserved = [p for p in candidates if p['start_pending_at'] and time.time() - p['start_pending_at'] < (60 if p.get('sino_profileless') else 45)
                    and p['limit_kw'] > 0 and id_tag == (p['identifier'] or ('EVSYS-' + self.id[:8] + '-' + str(p['connector']))[:20])]
        native = self.engine.subscription.status()['native'] and self.engine.config(self.id)['enabled'] and self.engine.config(self.id)['commissioned']
        return call_result.Authorize(id_tag_info={'status': 'Accepted' if reserved or native else 'Blocked'})

    @on(Action.start_transaction)
    async def start_transaction(self, connector_id, id_tag, meter_start, timestamp, **kwargs):
        p = self.port(connector_id)
        transaction_id = time.time_ns() % 2_000_000_000
        if not p:
            return call_result.StartTransaction(transaction_id=transaction_id, id_tag_info={'status': 'Invalid'})
        settings = self.engine.store.settings()
        now = time.time()
        blocked = blocked_at(datetime.now(timezone.utc), settings['schedules'], settings['timezone'])
        config = self.engine.config(self.id)
        evid = config.get('sino_evid') or p.get('sino_evid_pending') or self.evid_grant is not None
        evid_match = bool(config.get('sino_evid') and self.evid_grant
                          and self.evid_grant[:2] == (connector_id, id_tag)
                          and 0 <= now - self.evid_grant[2] < EVID_WINDOW)
        start_window = EVID_WINDOW if evid else 60 if p.get('sino_profileless') else 45
        allowed = bool(p['start_pending_at'] and 0 <= now - p['start_pending_at'] < start_window and p['limit_kw'] > 0
                       and not p['manual_pause'] and self.engine.config(self.id)['enabled']
                       and self.engine.config(self.id)['commissioned']
                       and self.engine.meter['at'] and now - self.engine.meter['at'] <= settings['freshness_s']
                       and self.engine.meter['total_kw'] <= settings['limit_kw'] - settings['margin_kw'] + 0.001
                       and (not blocked or p['emergency_until'] > now))
        if p.get('sino_profileless') and not self.engine.subscription.status()['native']:
            allowed = allowed and bool(p.get('sino_start_pending'))
        if self.engine.subscription.status()['native']:
            allowed = config['enabled'] and config['commissioned']
        if evid:
            allowed = (allowed and evid_match and p['connected'] and not p['running'] and not p['manual_pause']
                       and p['ocpp_status'] in ('Preparing', 'Charging', 'SuspendedEV', 'SuspendedEVSE')
                       and not p.get('station_alarm') and p.get('error_code', 'NoError') == 'NoError'
                       and not any(q['connected'] and not q['running'] and q is not p and q['charger'] == self.id
                                   and q['ocpp_status'] == 'Preparing' for q in self.engine.ports.values()))
        if not allowed:
            self.engine.store.record('unexpected_start', {'port': p['key'], 'action': 'rejected; inspect physical equipment'})
            # Run after sending the response, never await a call from inside an OCPP request handler.
            async def stop_unexpected():
                await asyncio.sleep(0.1)
                try:
                    await self.call(call.RemoteStopTransaction(transaction_id=transaction_id))
                except Exception:
                    pass
            asyncio.create_task(stop_unexpected())
            return call_result.StartTransaction(transaction_id=transaction_id, id_tag_info={'status': 'Blocked'})
        if evid:
            self.evid_grant = None
            self.engine.identify_evid(p, id_tag)
        elif not id_tag.startswith('EVSYS-'):
            self.engine.identify(p, id_tag)
        p['meter_kwh'] = meter_start / 1000
        p['connected'] = True
        self.engine.start_session(p, transaction_id)
        if p.get('sino_start_pending'):
            p.update(sino_start_pending=False, sino_evid_pending=False, sino_initial_pending=True,
                     profile_initialized=False, last_command_at=0)
        return call_result.StartTransaction(transaction_id=transaction_id, id_tag_info={'status': 'Accepted'})

    @on(Action.stop_transaction)
    async def stop_transaction(self, meter_stop, timestamp, transaction_id, **kwargs):
        p = next((p for p in self.engine.ports.values() if p['charger'] == self.id and p['transaction_id'] == transaction_id), None)
        if p:
            self.engine.telemetry(p, energy_kwh=meter_stop / 1000)
            self.engine.finish(p, kwargs.get('reason', 'Sessão encerrada pelo carregador'))
            # Do not immediately restart a completed session on the same cable connection.
            p['manual_pause'] = True
        return call_result.StopTransaction(id_tag_info={'status': 'Accepted'})

    @on(Action.meter_values)
    async def meter_values(self, connector_id, meter_value, **kwargs):
        p = self.port(connector_id)
        if p:
            transaction_id = kwargs.get('transaction_id')
            for item in meter_value:
                try:
                    sampled_at = datetime.fromisoformat(item['timestamp'].replace('Z', '+00:00')).timestamp()
                except (ValueError, KeyError):
                    continue
                # Replayed/offline measurements must not confirm a real-time decrease.
                age = time.time() - sampled_at
                if age > self.engine.store.settings()['freshness_s'] or age < -5 or sampled_at <= p['last_telemetry_at']:
                    continue
                p['last_telemetry_at'] = sampled_at
                power = energy = soc = voltage = None
                phases = {}
                for value in item.get('sampled_value', []):
                    try:
                        number = float(value['value'])
                    except (ValueError, KeyError):
                        continue
                    measurand = value.get('measurand', 'Energy.Active.Import.Register')
                    unit = value.get('unit', 'Wh' if measurand.startswith('Energy') else 'W')
                    location = value.get('location', 'Outlet')
                    if measurand == 'Power.Active.Import':
                        converted = number if unit == 'kW' else number / 1000
                        if value.get('phase') in ('L1', 'L2', 'L3'):
                            phases[value['phase']] = converted
                        elif not value.get('phase'):
                            power = converted
                    elif measurand == 'Energy.Active.Import.Register' and not value.get('phase'):
                        energy = number if unit == 'kWh' else number / 1000
                    elif measurand == 'SoC':
                        soc = number
                    elif measurand == 'Voltage' and location=='Outlet' and not value.get('phase'):
                        voltage=number/1000 if unit=='mV' else number*1000 if unit=='kV' else number if unit=='V' else None
                if power is None and set(phases) == {'L1', 'L2', 'L3'}:
                    power = sum(phases.values())
                self.engine.telemetry(p, power, energy, soc, sampled_at=sampled_at,voltage_v=voltage)
                if transaction_id is not None and not p['running'] and p['connected']:
                    p['manual_pause'] = not self.engine.subscription.status()['native']
                    self.engine.start_session(p, transaction_id)
                    p['profile_initialized'] = False
                    self.engine.store.record('session_reconciled', {'port': p['key'], 'transaction': transaction_id,
                                                                   'note': 'Recuperada a partir de leitura atual; retomada manual necessária'})
        return call_result.MeterValues()

    @on(Action.data_transfer)
    async def data_transfer(self, vendor_id, **kwargs):
        self.engine.store.record('vendor_extension', {'charger': self.id, 'vendor': vendor_id,
                                                     'message': kwargs.get('message_id'),
                                                     'note': 'Integração específica ainda não homologada'})
        return call_result.DataTransfer(status='UnknownMessageId')

    def profile(self, connector, kw, purpose='TxDefaultProfile'):
        c = self.engine.config(self.id)
        if kw>0 and c.get('charge_type')=='AC' and kw<6*c['voltage']*c['phases']/1000-1e-6:raise ValueError('Limite AC abaixo de 6 A')
        if c['rate_unit'] == 'A':
            if c.get('charge_type')=='DC':
                p=self.port(connector)
                if kw>0 and (not p or not p.get('voltage_v') or not 0<=time.time()-p.get('voltage_at',0)<=self.engine.store.settings()['freshness_s']):
                    raise ValueError('Perfil DC em A exige tensão atual de saída; use W se o equipamento não informa essa tensão')
                limit=kw*1000/p['voltage_v'] if kw>0 else 0
            else:limit = kw * 1000 / (c['voltage'] * c['phases'])
            if kw>0 and c.get('charge_type')=='AC' and limit<6-1e-6:raise ValueError('Limite AC abaixo de 6 A')
        else:
            limit = kw * 1000
        limit=math.floor((limit+1e-8)*10)/10
        if kw>0 and limit<=0:raise ValueError('Limite inferior à resolução do perfil')
        port = self.port(connector)
        start = (datetime.now(timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')
                 if port and port.get('sino_profileless') else utc())
        schedule = {'startSchedule': start, 'chargingRateUnit': c['rate_unit'], 'chargingSchedulePeriod': [
            {'startPeriod': 0, 'limit': limit}]}
        if c.get('charge_type')=='AC':schedule['chargingSchedulePeriod'][0]['numberPhases']=c['phases']
        return {'chargingProfileId': connector, 'stackLevel': 1,
                'chargingProfilePurpose': purpose, 'chargingProfileKind': 'Absolute',
                'chargingSchedule': schedule}

    async def limit(self, connector, kw):
        p = self.port(connector)
        active = p and p['transaction_id'] is not None
        profile = self.profile(connector, kw, 'TxProfile' if active else 'TxDefaultProfile')
        if active:
            profile['transactionId'] = p['transaction_id']
        response = await self.call(call.SetChargingProfile(connector_id=connector,
                                   cs_charging_profiles=profile))
        if p and response.status=='Accepted' and self.engine.config(self.id).get('charge_type')=='DC' and self.engine.config(self.id)['rate_unit']=='A':
            amps=profile['chargingSchedule']['chargingSchedulePeriod'][0]['limit']
            if p.get('accepted_profile_current_a')!=amps:p['accepted_profile_at']=time.time()
            p['accepted_profile_current_a']=amps
        return response.status == 'Accepted'

    async def release_native(self, connector):
        # IDs used by previous D-Max releases are connector numbers. Clearing by
        # ID preserves unrelated local/operator profiles; never issue a broad clear.
        result = await self.call(call.ClearChargingProfile(id=connector))
        if result.status == 'Accepted':
            return True
        # Unknown is ambiguous in 1.6 (absent or failed). Keep it pending for
        # commissioning rather than claiming that native operation is confirmed.
        return False

    async def remote_stop(self, transaction_id):
        reply = await self.call(call.RemoteStopTransaction(transaction_id=transaction_id))
        return reply is not None and reply.status == 'Accepted'

    async def remote_start(self, p, native=False, without_profile=False):
        if not native and self.engine.subscription.status()['native']:
            return
        identifier = p['identifier'] or ('EVSYS-' + self.id[:8] + '-' + str(p['connector']))[:20]
        options = {} if native or without_profile else {'charging_profile': self.profile(p['connector'], p['limit_kw'], 'TxProfile')}
        result = await self.call(call.RemoteStartTransaction(connector_id=p['connector'], id_tag=identifier, **options))
        if result is not None and result.status == 'Rejected':
            self.engine.store.record('start_rejected', {'port': p['key']})
            return False
        if result is None or result.status != 'Accepted':
            raise RuntimeError('Partida sem resposta conclusiva')
        return True
