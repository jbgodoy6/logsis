'use strict';

const dashboard = document.getElementById('dashboard');
const saver = document.getElementById('saver');
const mark = document.getElementById('mark');
const demand = document.getElementById('demand');
const ports = document.getElementById('ports');
const curve = document.getElementById('curve');
const ctx = curve.getContext('2d');
const number = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 });
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const idleMs = 60_000;
let idleTimer, frame, currentData;

function bounce(value) {
  return 1 - Math.abs(1 - value % 2);
}

function showSaver() {
  dashboard.inert = true;
  saver.hidden = false;
  const start = performance.now();
  function animate(now) {
    const seconds = reducedMotion.matches ? 0 : (now - start) / 1000;
    const edge = Math.min(innerWidth, innerHeight) * .045;
    const x = edge + Math.max(0, innerWidth - mark.offsetWidth - edge * 2) * bounce(.04 + seconds / 42);
    const y = edge + Math.max(0, innerHeight - mark.offsetHeight - edge * 2) * bounce(1.64 + seconds / 52);
    mark.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)';
    frame = requestAnimationFrame(animate);
  }
  frame = requestAnimationFrame(animate);
}

function resetIdle() {
  clearTimeout(idleTimer);
  idleTimer = setTimeout(showSaver, idleMs);
}

function wake() {
  if (saver.hidden) return;
  saver.hidden = true;
  dashboard.inert = false;
  cancelAnimationFrame(frame);
  resetIdle();
}

for (const event of ['pointerdown', 'pointermove', 'wheel', 'keydown']) {
  dashboard.addEventListener(event, resetIdle, { passive: true });
}
saver.addEventListener('click', wake);
document.addEventListener('keydown', wake);
document.getElementById('fullscreen').addEventListener('click', async () => {
  if (document.fullscreenElement) await document.exitFullscreen();
  else await document.documentElement.requestFullscreen();
});

function renderCurve(data) {
  const width = curve.clientWidth;
  const height = curve.clientHeight;
  if (!width || !height) return;
  const scale = devicePixelRatio || 1;
  curve.width = width * scale;
  curve.height = height * scale;
  ctx.scale(scale, scale);
  ctx.font = '11px "Segoe UI", sans-serif';
  const series = [['total_kw', '#0765bf'], ['ev_kw', '#168161'], ['limit_kw', '#b65b25']];
  const peak = Math.max(1, data.limit, ...data.points.flatMap(point => series.map(([key]) => point[key] || 0)));
  const left = 43;
  const bottom = height - 17;
  const range = Math.max(1, data.end - data.start);
  for (let i = 0; i <= 3; i++) {
    const y = bottom - i * (bottom - 9) / 3;
    ctx.strokeStyle = '#dce7f0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(width - 4, y);
    ctx.stroke();
    ctx.fillStyle = '#4a6077';
    ctx.fillText(number.format(peak * i / 3), 0, y + 3);
  }
  for (const [key, color] of series) {
    let segment;
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash(key === 'limit_kw' ? [5, 4] : []);
    for (const point of data.points) {
      if (!Number.isFinite(point[key])) {
        segment = undefined;
        continue;
      }
      const x = left + (point.ts - data.start) / range * (width - left - 4);
      const y = bottom - point[key] / peak * (bottom - 9);
      if (segment !== point[key + '_segment']) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      segment = point[key + '_segment'];
    }
    ctx.stroke();
  }
  ctx.setLineDash([]);
  const format = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: data.timezone });
  ctx.fillStyle = '#4a6077';
  ctx.fillText(format.format(data.start * 1000), left, height - 3);
  const end = format.format(data.end * 1000);
  ctx.fillText(end, width - ctx.measureText(end).width - 3, height - 3);
  if (!data.points.length) ctx.fillText('Sem leituras no período', left + 10, bottom - 10);
}

function renderPorts(list) {
  const scroll = ports.scrollTop;
  const items = list.map(port => {
    const item = document.createElement('li');
    const tone = !port.online ? 'offline' : port.alarm ? 'alarm' : port.running ? 'running' : port.connected ? 'connected' : 'idle';
    const labels = { offline: 'Sem comunicação', alarm: 'Alarme', running: 'Carregando', connected: 'Conectado', idle: 'Disponível' };
    item.classList.add('port', tone);
    const name = document.createElement('strong');
    name.textContent = port.name + ' · ' + port.number;
    const detail = document.createElement('div');
    detail.className = 'port-detail';
    const state = document.createElement('p');
    state.textContent = labels[tone] + (port.online && port.soc != null ? ' · ' + number.format(port.soc) + '%' : '');
    const power = document.createElement('b');
    power.textContent = port.online && port.running ? number.format(port.power) + ' kW' : '—';
    detail.append(state, power);
    item.append(name, detail);
    return item;
  });
  if (!items.length) {
    const item = document.createElement('li');
    item.textContent = 'Nenhum carregador cadastrado';
    items.push(item);
  }
  ports.replaceChildren(...items);
  ports.scrollTop = scroll;
}

async function refresh() {
  try {
    const response = await fetch('/ui-data/hdmi', { cache: 'no-store', signal: AbortSignal.timeout(7000) });
    if (!response.ok) throw new Error('Monitor indisponível');
    currentData = await response.json();
    demand.textContent = currentData.meter_fresh ? number.format(currentData.total) + ' kW' : 'Sem leitura atual';
    renderCurve(currentData);
    renderPorts(currentData.ports);
  } catch {
    demand.textContent = 'Sem atualização';
  } finally {
    setTimeout(refresh, 3500);
  }
}

new ResizeObserver(() => { if (currentData) renderCurve(currentData); }).observe(curve);
resetIdle();
refresh();
